#' Classify peritonitis episode types for many episodes at once
#'
#' A vectorised counterpart to [get_episode_type()]. Each row is first checked
#' exactly as [pd_infection()] would check it, by building a `pd_infection`
#' with [new_pd_infection()] and passing it through `validate_pd_infection()`.
#' Valid rows are then classified as \code{"relapsing"}, \code{"recurrent"} or \code{"repeat"}
#' (ISPD 2022 definitions) against the same patient's immediately preceding
#' valid episode. By default the classification loop runs in C++; set
#' `use_cpp = FALSE` to run the equivalent pure-R loop instead.
#'
#' A row that fails validation (eg. a missing `last_dose_antibiotic`, or a
#' `"catheter removed"` outcome with no `outcome_date`) is returned as `NA` and
#' is **not** carried forward as the prior episode for the next row.
#' `pd_unit()` reports them among its data problems and builds no unit until they are fixed.
#'
#' Organism names are compared **as given**. Only `pd_unit()` standardises
#' spellings against the package's accepted list before classifying, so used on
#' its own this function treats `"E. coli"` and `"Escherichia coli"` as
#' different organisms.
#'
#' @param patient_id Character. Patient identifier for each episode.
#' @param infection_date Date. Date each episode was diagnosed.
#' @param last_dose_antibiotic Date. Date of the last antibiotic dose for each
#'   episode.
#' @param organism_list List, one element per episode, each itself a list of
#'   that episode's organism name(s). Use \code{"negative"} for culture-negative.
#' @param outcome Character. Outcome of each episode, or \code{NA} when resolved.
#'   Defaults to all \code{NA}.
#' @param outcome_date Date. Date of each outcome. Defaults to all \code{NA}.
#' @param use_cpp Logical. \code{TRUE} (the default) classifies with the compiled C++
#'   loop, which is faster on large inputs. \code{FALSE} uses a pure-R loop that calls
#'   [get_episode_type()] once per episode, and needs no compiled code. Both apply the
#'   same validation and the same ISPD rule, so the result is the same either way.
#'
#' @return Character vector, the same length as the inputs: \code{"relapsing"},
#'   \code{"recurrent"}, \code{"repeat"}, or \code{NA_character_} (first valid
#'   episode for a patient, invalid row, or no ISPD category applies). An `NA`
#'   is not a missing value and the episode still counts towards the peritonitis rate.
#' @seealso [get_episode_type()] for the single-episode version, and
#'   `vignette("indicators-classification", package = "peridial")` for the ISPD
#'   rule, a worked example and the compiled classifier.
#' @export
#'
#' @examples
#' \dontrun{
#' classify_episode_types(
#'   patient_id = c("patient01", "patient01", "patient02", "patient02"),
#'   infection_date = as.Date(c("2025-04-01", "2025-05-12",
#'                              "2025-03-31", "2025-07-13")),
#'   last_dose_antibiotic = as.Date(c("2025-04-15", "2025-06-01",
#'                                    "2025-04-14", "2025-07-27")),
#'   organism_list = list(list("E. coli"), list("E. coli"),
#'                        list("E. coli"), list("E. coli"))
#' )
#' # patient01's second episode is 27 days after the last dose, same organism: relapsing
#' # patient02's is 90 days after: repeat.
#' # Episodes are never compared across patients, so each patient's first is NA.
#' }
#'
classify_episode_types <- function(patient_id,
                                   infection_date,
                                   last_dose_antibiotic,
                                   organism_list,
                                   outcome = rep(NA_character_, length(patient_id)),
                                   outcome_date = rep(as.Date(NA), length(patient_id)),
                                   use_cpp = TRUE) {
  n <- length(patient_id)
  stopifnot(inherits(infection_date, "Date"),
            inherits(last_dose_antibiotic, "Date"),
            inherits(outcome_date, "Date"),
            is.list(organism_list),
            length(infection_date) == n,
            length(last_dose_antibiotic) == n,
            length(organism_list) == n,
            length(outcome) == n,
            length(outcome_date) == n,
            is.logical(use_cpp), length(use_cpp) == 1, !is.na(use_cpp)
            )

  # a malformed call, should be a list of lists
  not_list <- !vapply(organism_list, is.list, logical(1))
  if (any(not_list)) {
    stop("`organism_list` must be a list of lists, one inner list per episode, ",
         paste(which(not_list)[seq_len(min(5, sum(not_list)))], collapse = ", "))
  }

  # validate first, keeping the reason each row failed (NA = valid)
  problem <- vapply(seq_len(n), function(i) {
    tryCatch({
      validate_pd_infection(new_pd_infection(
        patient_id = patient_id[i],
        infection_date = infection_date[i],
        organism_list = organism_list[[i]],
        episode_type = NA_character_,
        last_dose_antibiotic = last_dose_antibiotic[i],
        outcome = outcome[i],
        outcome_date = outcome_date[i]
      ))
      NA_character_
    }, error = function(e) conditionMessage(e))
  }, character(1))
  valid <- is.na(problem)

  if (any(!valid)) {
    bad <- which(!valid)
    shown <- bad[seq_len(min(5, length(bad)))]
    warning(length(bad), " of ", n, " episode(s) failed validation and were left ",
            "unclassified (NA, and not used as a prior episode):\n",
            paste0("  row ", shown, ": ", problem[shown], collapse = "\n"))
  }

  ord <- order(patient_id, infection_date)   # grouped by patient and oldest infection first
  out <- character(n)

  if (use_cpp) {
    # one comparable string per episode, same as get_episode_type() - eg. lowercase and sorted
    key <- vapply(organism_list,
                  function(x) paste(sort(tolower(unlist(x))), collapse = "|"),
                  character(1)
                  )
    # Rcpp implementation of classify_episode_types_cpp
    out[ord] <- classify_episode_types_cpp(
      patient_id = as.character(patient_id)[ord],
      infection_date = as.numeric(infection_date)[ord],
      last_dose_antibiotic = as.numeric(last_dose_antibiotic)[ord],
      organism_key = key[ord],
      valid = valid[ord]
    )
  } else {
    out[ord] <- classify_episode_types_r(
      patient_id = as.character(patient_id)[ord],
      infection_date = infection_date[ord],
      last_dose_antibiotic = last_dose_antibiotic[ord],
      organism_list = organism_list[ord],
      valid = valid[ord]
    )
  }
  out
}



#' R equivalent of classify_episode_types_cpp()
#' @noRd
classify_episode_types_r <- function(patient_id, infection_date, last_dose_antibiotic,
                                     organism_list, valid) {
  out <- rep(NA_character_, length(patient_id))
  prior <- NULL
  prior_patient <- ""
  for (i in seq_along(patient_id)) {
    # a new patient has no prior episode
    if (!identical(patient_id[i], prior_patient)) prior <- NULL
    if (is.na(valid[i]) || !valid[i]) next

    out[i] <- get_episode_type(infection_date[i], organism_list[[i]], prior)

    prior <- new_pd_infection(patient_id = patient_id[i],
                              infection_date = infection_date[i],
                              organism_list = organism_list[[i]],
                              last_dose_antibiotic = last_dose_antibiotic[i])
    prior_patient <- patient_id[i]
  }
  out
}
