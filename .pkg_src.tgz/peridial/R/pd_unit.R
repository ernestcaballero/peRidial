
#' Create a pd_unit object
#'
#' Low-level constructor for the unit-level reporting object. It wraps a PD
#' unit's patients, catheters and peritonitis episodes, both as flat tibbles
#' and as the nested \code{pd_patient} object list they were derived from;
#' together with the reporting period and the headline counts the ISPD
#' indicators are built from.
#'
#' @param unit_id Character. Name of the PD unit (e.g. "XYZ PD Unit").
#' @param t0 Date. Start of the reporting period. Usually 1st day of January of the reporting year.
#' @param t1 Date. End of the reporting period. Usually 31st day of December of the reporting year.
#' @param n_new Integer. Number of incident ("new") patients in the reporting
#'   period, i.e. the count of \code{patient_list} entries whose \code{new_patient_flag} is \code{TRUE}.
#' @param n_patients Integer. Size of the reporting cohort: every patient who
#'   was on PD at any point during \code{[t0, t1]} (prevalent at \code{t0}
#'   plus incident within the period), including those who died or left PD
#'   part-way through. Must equal both \code{nrow(patients)} and
#'   \code{length(patient_list)}.
#' @param tpyar Numeric. Total patient-years at risk across the cohort: the
#'   time patients actively spent on PD within \code{[t0, t1]}, censored at
#'   each patient's \code{tau}, expressed in years. This is the denominator
#'   (PY) of the peritonitis rate. Derived by \code{\link{total_patient_years}()}.
#' @param rate_benchmark Numeric. The ISPD peritonitis-rate benchmark for
#'   this unit, in episodes per patient-year: the headline rate is judged
#'   "MET" when it is at or below this value. Carried on the object so
#'   \code{summary.pd_unit()} and \code{plot.pd_unit()} judge and plot
#'   against the same threshold by default. Defaults to 0.40, the ISPD
#'   standard.
#' @param pf_benchmark Numeric. The ISPD peritonitis-free benchmark for this
#'   unit, as a proportion between 0 and 1: the peritonitis-free percentage
#'   is judged "MET" when it is strictly above this value. Carried on the
#'   object so \code{summary.pd_unit()} and \code{plot.pd_unit()} judge and
#'   plot against the same threshold. Defaults to 0.80 (i.e. 80\%), the ISPD
#'   standard.
#' @param patients Tibble. One row per patient, flattened from
#'   \code{patient_list}.
#' @param catheters Tibble. One row per catheter, flattened from the
#'   \code{pd_catheter} objects nested inside \code{patient_list}.
#' @param infections Tibble. One row per peritonitis episode, flattened from
#'   the \code{pd_infection} objects nested inside each catheter, and carrying
#'   the \code{catheter_id} of the catheter that owns it.
#' @param patient_list List of \code{pd_patient} objects: the nested object
#'   graph the three tibbles above are views of.
#'
#' @return An object of class \code{pd_unit}.
#' @seealso \code{\link{pd_unit}()} to build one from raw data files.
#' @export
#'
#' @examples
#' # An empty unit for a period with no patients.
#' new_pd_unit(
#'   unit_id = "Wellington PD Unit",
#'   t0 = as.Date("2025-01-01"),
#'   t1 = as.Date("2025-12-31"),
#'   n_new = 0L,
#'   n_patients = 0L,
#'   tpyar = 0
#' )
new_pd_unit <- function(unit_id = NA_character_,
                        t0 = as.Date(NA),        # start date
                        t1 = as.Date(NA),        # end date
                        n_new = NA_integer_,
                        n_patients = NA_integer_,
                        tpyar = NA_real_,        # total patient-years-at-risk
                        rate_benchmark = 0.40,   # ISPD peritonitis-rate benchmark
                        pf_benchmark = 0.80,     # ISPD peritonitis-free benchmark (proportion)
                        patients = tibble::tibble(),
                        catheters = tibble::tibble(),
                        infections = tibble::tibble(),
                        patient_list = list()) {

  stopifnot(length(unit_id) == 1, is.character(unit_id))
  stopifnot(inherits(t0, "Date"), length(t0) == 1)
  stopifnot(inherits(t1, "Date"), length(t1) == 1)
  stopifnot(length(n_new) == 1, is.na(n_new) || is.numeric(n_new))
  stopifnot(length(n_patients) == 1, is.na(n_patients) || is.numeric(n_patients))
  stopifnot(length(tpyar) == 1, is.na(tpyar) || is.numeric(tpyar))
  stopifnot(length(rate_benchmark) == 1, is.numeric(rate_benchmark))
  stopifnot(length(pf_benchmark) == 1, is.numeric(pf_benchmark))
  stopifnot(is.data.frame(patients), is.data.frame(catheters),
            is.data.frame(infections))
  stopifnot(is.list(patient_list))

  structure(
    list(
      unit_id = unit_id,
      t0 = t0,
      t1 = t1,
      n_new = n_new,
      n_patients = n_patients,
      tpyar = tpyar,
      rate_benchmark = rate_benchmark,
      pf_benchmark = pf_benchmark,
      patients = patients,
      catheters = catheters,
      infections = infections,
      patient_list = patient_list
    ),
    class = "pd_unit"
  )
}



validate_pd_unit <- function(x) {
  stopifnot(inherits(x, "pd_unit"))

  # checks if dates are missing
  if (is.na(x$t0) || is.na(x$t1)) {
    stop("Both t0 and t1 must be supplied.")
  }
  # checks if start date is later than end date
  if (x$t0 > x$t1) {
    stop("t0 must be on or before t1.")
  }

  # checks n_new and n_patients are missing
  if (is.na(x$n_new) || is.na(x$n_patients)) {
    stop("Both n_new and n_patients must be supplied.")
  }
  if (x$n_new < 0 || x$n_patients < 0) {
    stop("n_new and n_patients cannot be negative.")
  }
  # incident patients are a subset of the cohort, so this can't exceed it
  if (x$n_new > x$n_patients) {
    stop("n_new cannot exceed n_patients.")
  }
  # checks if total_patient_yrs_at_risk is missing
  if (is.na(x$tpyar)) {
    stop("Total patient-years-at-risk (tpyar) is missing.")
  }
  # checks if tpyar is less than 0
  if (x$tpyar < 0) {
    stop("Total patient-years-at-risk cannot be negative.")
  }
  # No patient can contribute more than the full period, so the cohort can't
  # accrue more patient-years than n_patients * the period's own length
  period_years <- as.numeric(x$t1 - x$t0 + 1) / 365.25
  if (x$tpyar > x$n_patients * period_years + 1e-8) {
    stop("Total patient-years-at-risk (", round(x$tpyar, 3), ") exceeds the ",
         "maximum possible for ", x$n_patients, " patients over a reporting ",
         "period of ", round(period_years, 3), " years.")
  }

  # checks rate_benchmark is present and sane
  if (is.na(x$rate_benchmark)) {
    stop("rate_benchmark is missing.")
  }
  if (x$rate_benchmark < 0) {
    stop("rate_benchmark cannot be negative.")
  }

  # checks pf_benchmark is present and is a proportion
  if (is.na(x$pf_benchmark)) {
    stop("pf_benchmark is missing.")
  }
  if (x$pf_benchmark < 0 || x$pf_benchmark > 1) {
    stop("pf_benchmark must be a proportion between 0 and 1.")
  }

  # `patients` and `patient_list` are two views of the same cohort: must match (nrow(patients) = n_patients)
  # We need to settle that they agree before checking anything that references them.
  if (nrow(x$patients) != x$n_patients) {
    stop("nrow(patients) (", nrow(x$patients), ") does not match n_patients (",
         x$n_patients, ").")
  }
  if (nrow(x$patients) > 0) {
    require_cols(x$patients, c("patient_id",
                               "n_episodes"), "patients", kind = "table")
    if (anyDuplicated(x$patients$patient_id) > 0) {
      stop("Duplicate patient_id(s) in `patients`: ",
           paste(unique(x$patients$patient_id[duplicated(x$patients$patient_id)]),
                 collapse = ", "), ".")
    }
  }
  # checks patient_list length matches n_patients
  if (length(x$patient_list) != x$n_patients) {
    stop("Length of `patient_list` (", length(x$patient_list), ") does not ",
         "match n_patients (", x$n_patients, ").")
  }
  # checks if patient_list is a pd_patient object
  if (length(x$patient_list) > 0) {
    for (i in seq_along(x$patient_list)) {
      p <- x$patient_list[[i]]
      if (!inherits(p, "pd_patient")) {
        stop("patient_list[[", i, "]] is not a pd_patient object.")
      }
      # every patient must be scoped to the unit's reporting window
      if (!identical(p$t0, x$t0) || !identical(p$t1, x$t1)) {
        stop("patient_list[[", i, "]] has a reporting window that differs from this unit's [t0, t1].")
      }
    }

    # the tibble is a view of the patient_list, so the two must agree
    obj_ids <- vapply(x$patient_list, function(p) p$patient_id, character(1))
    if (nrow(x$patients) > 0 && !setequal(obj_ids, x$patients$patient_id)) {
      stop("The patient_id values in `patients` do not match those in `patient_list`.")
    }

    # n_new is defined as the count of incident patients in patient_list
    expected_new <- sum(vapply(x$patient_list,
                               function(p) isTRUE(p$new_patient_flag),
                               logical(1)))
    if (x$n_new != expected_new) {
      stop("n_new (", x$n_new, ") does not match the number of patients in ",
           "`patient_list` flagged as incident (", expected_new, ").")
    }
  }

  # checks catheters reference a valid patient_id
  if (nrow(x$catheters) > 0) {
    require_cols(x$catheters, c("patient_id",
                                "catheter_id"), "catheters", kind = "table")
    if (!all(x$catheters$patient_id %in% x$patients$patient_id)) {
      stop("Some catheter records reference a patient_id not present in `patients`.")
    }
    # catheter_id is the key infections are matched on, so it must be unique
    # across the whole unit, not just within a patient
    if (anyDuplicated(x$catheters$catheter_id) > 0) {
      stop("Duplicate catheter_id(s) in `catheters`: ",
           paste(unique(x$catheters$catheter_id[duplicated(x$catheters$catheter_id)]),
                 collapse = ", "), ".")
    }
  }
  # checks infections reference a valid catheter_id
  if (nrow(x$infections) > 0) {
    require_cols(x$infections, c("patient_id",
                                 "catheter_id",
                                 "infection_date",
                                 "counts_toward_rate"), "infections", kind = "table")
    if (!all(x$infections$catheter_id %in% x$catheters$catheter_id)) {
      stop("Some infection records reference a catheter_id not present in `catheters`.")
    }
    if (!all(x$infections$patient_id %in% x$patients$patient_id)) {
      stop("Some infection records reference a patient_id not present in `patients`.")
    }
  }

  x
}




#' Build a pd_unit object from raw data files
#'
#' Reads a unit's raw dialysis (A3) file and peritonitis-episode (PE) file and
#' builds the full nested object graph for a reporting period:
#' peritonitis episodes owned by the catheter that was active when they occurred,
#' catheters owned by their patient, and every patient who was on PD at any
#' point in \code{[t0, t1]} collected into one \code{pd_unit}.
#'
#' The returned object carries both the nested \code{patient_list} and three
#' flat tibbles (\code{patients}, \code{catheters}, \code{infections})
#' derived from it, plus the headline numbers the ISPD indicators need:
#' \code{n_new}, \code{n_patients} and \code{tpyar}.
#'
#' @param unit_data The raw unit (A3) data, containing both patient and
#'   catheter data: either a path to an Excel (\code{.xlsx}) or CSV (\code{.csv})
#'   file, or a data frame already in R.
#' @param infection_data The raw infection/peritonitis episode (PE) data: an Excel
#'   or CSV file path, or a data frame. For patients who were already on PD at
#'   \code{t0}, include their episodes from at least 28 days before \code{t0}.
#'   These earlier episodes are used only to classify later ones and are not counted.
#'   If they are left out, a patient's first episode in the period can be
#'   a relapse that is counted as new, and \code{pd_unit()} gives a warning naming those patients.
#' @param t0 Date. Start of the reporting period.
#' @param t1 Date. End of the reporting period.
#' @param unit_id Character. Identifier for the unit, e.g.
#'   \code{"Auckland PD Unit"}. Defaults to \code{NA_character_}.
#' @param rate_benchmark Numeric. The ISPD peritonitis-rate benchmark for
#'   this unit, in episodes per patient-year, used by \code{summary.pd_unit()}
#'   and \code{plot.pd_unit()} to plot the headline rate against.
#'   Defaults to 0.40, the ISPD recommendation.
#' @param pf_benchmark Numeric. The ISPD peritonitis-free benchmark for this
#'   unit, as a proportion between 0 and 1, used by \code{summary.pd_unit()}
#'   and \code{plot.pd_unit()} to judge/plot the peritonitis-free percentage against.
#'   Defaults to 0.80, the ISPD recommendation.
#' @param censor_on_last_stop Logical. Treat a patient whose every catheter
#'   has closed, with none reopened, as having left PD on the last
#'   \code{pd_stop_date}, recording \code{transfer_reason = "pd stopped"}.
#'   Defaults to \code{TRUE}. Set \code{FALSE} if your
#'   unit records genuine breaks from PD, since a break and a permanent exit
#'   look identical in the raw data.
#'
#' @section Input data:
#' Column names are matched ignoring capitalisation, spacing and punctuation,
#' so \code{Patient ID}, \code{patient_id} and \code{PatientID} are the same
#' column. Beyond that the match is on keywords, so \code{Infection Date} is
#' read as \code{Date of Infection}, \code{DOB} as \code{Date of Birth} and
#' \code{Sex} as \code{Gender}. An exactly named column will always be chosen;
#' where two or more columns could match one target, the leftmost is used and
#' a warning lists the candidates.
#'
#' \describe{
#'   \item{\code{unit_data} (A3), required}{\code{Patient ID},
#'     \code{Insertion Date}, \code{PD Start Date}, \code{Date of Birth}.}
#'   \item{\code{unit_data} (A3), optional}{\code{Gender}, \code{Ethnicity},
#'     \code{Primary Kidney Disease}, \code{Height}, \code{Weight},
#'     \code{Cigarette Smoking Status}, \code{Diabetes Type},
#'     \code{Procedure Type}, \code{PD Stop Date}, \code{Removal Reason},
#'     \code{Dialysis Type}, \code{Dialysis Modality Change},
#'     \code{Modality Change Reason}, \code{Date Modality Change},
#'     \code{Date of Death}, \code{Cause of Death}, \code{Transplant Date}.}
#'   \item{\code{infection_data} (PE), required}{\code{Patient ID},
#'     \code{Date of Infection}, \code{Organism}, \code{Last Dose Antibiotic}.}
#'   \item{\code{infection_data} (PE), optional}{\code{Overnight Hospitalisation},
#'     \code{Days Hospitalised}, \code{Catheter Removed},
#'     \code{Catheter Removed Date}, \code{Interim HD}, \code{Permanent HD},
#'     \code{First Dialysis Date}, \code{Last Dialysis Date}.}
#' }
#'
#' A missing required column stops the build. A missing optional column is
#' filled with \code{NA} without a warning, so check the spelling of optional
#' columns carefully: a mis-named \code{Date of Death} or \code{PD Stop Date}
#' means patients are not censored and patient-years are overstated.
#'
#' Values are expected decoded rather than coded (\code{Gender} holds
#' \code{"Female"}, not a registry code), and:
#' \itemize{
#'   \item \code{Patient ID} must be in NHI format, three letters then four
#'     digits (\code{ABC1234}), case-insensitive.
#'   \item Dates may be Excel date cells, \code{Date} columns, or text in
#'     \code{YYYY-MM-DD} or day-first form (\code{31/01/2025},
#'     \code{31-01-2025}).
#'   \item Yes/no columns accept \code{Yes}/\code{No}, \code{Y}/\code{N},
#'     \code{TRUE}/\code{FALSE} or \code{1}/\code{0}.
#'   \item Several organisms for one episode go in one cell, separated by a
#'     comma, semicolon, \code{&}, \code{+}, \code{/} or the word "and".
#'     Spellings are standardised against the package's accepted list.
#'   \item A permanent move to haemodialysis is recorded as
#'     \code{Any PD to HD} in \code{Dialysis Modality Change}.
#' }
#'
#'
#' @return A validated \code{pd_unit} object.
#' @seealso \code{\link{new_pd_unit}()} for the underlying constructor.
#'   \code{vignette("peridial", package = "peridial")} works through building a
#'   unit from the example files, preparing your own data, and reading a failed
#'   build; \code{vignette("data-structures", package = "peridial")} describes
#'   the object graph it returns.
#' @export
#'
#' @examples
#' \dontrun{
#' unit <- pd_unit(
#'   unit_data = system.file("extdata", "a3_2025.xlsx",
#'                           package = "peridial", mustWork = TRUE),
#'   infection_data = system.file("extdata", "pe_2025.xlsx",
#'                                package = "peridial", mustWork = TRUE),
#'   t0 = as.Date("2025-01-01"),
#'   t1 = as.Date("2025-12-31"),
#'   unit_id = "Wellington PD Unit"
#' )
#' unit
#' }
#'
pd_unit <- function(unit_data,
                    infection_data,
                    t0,
                    t1,
                    unit_id = NA_character_,
                    rate_benchmark = 0.40,
                    pf_benchmark = 0.80,
                    censor_on_last_stop = TRUE) {

  stopifnot(inherits(t0, "Date"), length(t0) == 1, !is.na(t0))
  stopifnot(inherits(t1, "Date"), length(t1) == 1, !is.na(t1))
  if (t0 > t1) {
    stop("t0 must be on or before t1.")
  }

  log <- new_issue_log()

  # Read file and standardise
  raw_a3 <- standardise_names(read_input(unit_data, "unit_data"))
  raw_pe_file <- standardise_names(read_input(infection_data, "infection_data"))

  # map differently-named columns onto the expected names by keyword; logged
  raw_a3 <- map_columns(raw_a3, a3_spec, "unit (A3)", log)
  raw_pe_file <- map_columns(raw_pe_file, pe_spec, "infection (PE)", log)

  a3_required_cells <- c("patient_id", "date_of_birth", "insertion_date", "pd_start_date")
  pe_required_cells <- c("patient_id", "date_of_infection", "organism", "last_dose_antibiotic")

  require_cols(raw_a3, a3_required_cells, "unit (A3)")
  require_cols(raw_pe_file, pe_required_cells, "infection (PE)")

  a3_optional <- c("gender", "ethnicity",
                   "primary_kidney_disease", "height", "weight",
                   "cigarette_smoking_status", "diabetes_type",
                   "dialysis_modality_change", "modality_change_reason",
                   "date_modality_change", "date_of_death", "cause_of_death",
                   "transplant_date", "dialysis_type",
                   "procedure_type", "pd_stop_date", "removal_reason")
  raw_a3 <- ensure_cols(raw_a3, a3_optional)

  pe_optional <- c("overnight_hospitalisation", "days_hospitalised",
                   "catheter_removed", "catheter_removed_date", "interim_hd",
                   "permanent_hd", "first_dialysis_date", "last_dialysis_date")
  raw_pe_file <- ensure_cols(raw_pe_file, pe_optional)

  # ensure to note each row's original position in the source, for error messaging purposes
  a3_header_rows <- if (is.data.frame(unit_data)) 0L else 1L
  pe_header_rows <- if (is.data.frame(infection_data)) 0L else 1L
  raw_a3$.sheet_row <- seq_len(nrow(raw_a3)) + a3_header_rows
  raw_pe_file$.sheet_row <- seq_len(nrow(raw_pe_file)) + pe_header_rows

  # a blank required cell is logged and its row dropped
  raw_a3 <- check_required_cells(raw_a3, a3_required_cells, "unit (A3)", log)
  raw_pe_file <- check_required_cells(raw_pe_file, pe_required_cells, "infection (PE)", log)

  # a patient_id that is not a valid NHI is logged and its row dropped
  raw_a3 <- check_patient_ids(raw_a3, "unit (A3)", log)
  raw_pe_file <- check_patient_ids(raw_pe_file, "infection (PE)", log)

  # an episode for a patient who is not in the A3 file would silently match no catheter
  raw_pe_file <- check_known_patients(raw_pe_file, trimws(as.character(raw_a3$patient_id)),
                                      "infection (PE)", log)

  # organisms are matched against the ANZDATA PE form's list and given standard names
  raw_pe_file <- check_organisms(raw_pe_file, "infection (PE)", log)

  # removal reasons (catheter removal, and the reason for a modality change) are checked against the list in value_maps.R
  raw_a3$removal_reason <- standardise_removal_reason(raw_a3$removal_reason)
  raw_a3$modality_change_reason <- standardise_removal_reason(raw_a3$modality_change_reason)

  # tidy the A3 form into patients, catheters and modality changes
  raw_a3 <- raw_a3 |>
    dplyr::mutate(
      patient_id = trimws(as.character(patient_id)),
      date_of_birth = as_date_safe(date_of_birth, "date_of_birth"),
      date_of_death = as_date_safe(date_of_death, "date_of_death"),
      date_modality_change = as_date_safe(date_modality_change,"date_modality_change"),
      insertion_date = as_date_safe(insertion_date, "insertion_date"),
      pd_start_date = as_date_safe(pd_start_date, "pd_start_date"),
      pd_stop_date = as_date_safe(pd_stop_date, "pd_stop_date")
    )

  raw_patients <- raw_a3 |>
    dplyr::select(dplyr::any_of(c(
      "patient_id", "date_of_birth", "gender", "ethnicity",
      "primary_kidney_disease", "height", "weight",
      "cigarette_smoking_status", "diabetes_type", "date_of_death",
      "cause_of_death", "dialysis_type", "transplant_date"))) |>
    dplyr::distinct(patient_id, .keep_all = TRUE)

  raw_catheters <- raw_a3 |>
    dplyr::select(dplyr::any_of(c(
      "patient_id", "insertion_date", "procedure_type", "pd_start_date",
      "pd_stop_date", "removal_reason"))) |>
    dplyr::filter(!is.na(patient_id)) |>
    dplyr::mutate(catheter_id = create_catheter_id(patient_id, insertion_date))

  raw_modality <- raw_a3 |>
    dplyr::select(dplyr::any_of(c(
      "patient_id", "dialysis_modality_change", "modality_change_reason", "date_modality_change")))

  # tidy the PE form into episodes
  raw_pe_episodes <- raw_pe_file |>
    dplyr::mutate(
      patient_id = trimws(as.character(patient_id)),
      date_of_infection = as_date_safe(date_of_infection, "date_of_infection"),
      last_dose_antibiotic = as_date_safe(last_dose_antibiotic, "last_dose_antibiotic"),
      catheter_removed_date = as_date_safe(catheter_removed_date, "catheter_removed_date"),
      first_dialysis_date = as_date_safe(first_dialysis_date, "first_dialysis_date"),
      last_dialysis_date = as_date_safe(last_dialysis_date, "last_dialysis_date"),
      catheter_removed = as_logical_safe(catheter_removed), # normalise the yes/no flags before case_when() combines them
      permanent_hd = as_logical_safe(permanent_hd),
      interim_hd = as_logical_safe(interim_hd),
      overnight_hospitalisation = as_logical_safe(overnight_hospitalisation)
    ) |>
    dplyr::mutate(
      # each element must itself be a list: new_pd_infection() and get_episode_type() both require is.list(organism_list)
      organism_list = lapply(strsplit(as.character(organism), ",\\s*"),
                             function(z) as.list(trimws(z))),
      # Outcome priority is catheter removal > permanent HD > temporary HD > hospitalisation; the most severe flag set wins.
      outcome = dplyr::case_when(
        dplyr::coalesce(catheter_removed, FALSE)          ~ "catheter removed",
        dplyr::coalesce(permanent_hd, FALSE)              ~ "permanent transfer to HD",
        dplyr::coalesce(interim_hd, FALSE)                ~ "temporary transfer to HD",
        dplyr::coalesce(overnight_hospitalisation, FALSE) ~ "hospitalisation",
        TRUE ~ NA_character_
      ),
      # outcome/outcome_date can be nullable: resolved episode falls through to NA, which validate_pd_infection() reads as implied good recovery
      outcome_date = dplyr::case_when(
        dplyr::coalesce(catheter_removed, FALSE) ~ catheter_removed_date,
        dplyr::coalesce(permanent_hd, FALSE) |
          dplyr::coalesce(interim_hd, FALSE)     ~ first_dialysis_date,
        TRUE ~ as.Date(NA)
      )
    ) |>
    dplyr::arrange(patient_id, date_of_infection)

  # Derive tau per patient, then censor the catheter windows
  pids <- sort(unique(raw_catheters$patient_id))
  taus <- list()
  for (pid in pids) {
    taus[[pid]] <- derive_patient_tau(
      demo = raw_patients[raw_patients$patient_id == pid, , drop = FALSE],
      mod  = raw_modality[raw_modality$patient_id == pid, , drop = FALSE],
      cath = raw_catheters[raw_catheters$patient_id == pid, , drop = FALSE],
      censor_on_last_stop = censor_on_last_stop
    )
    tau <- taus[[pid]]$date

    # tau is the authority on when PD ended: close any catheter left open past it, and pull back any that claims to have ran beyond it
    if (!is.na(tau)) {
      rows <- which(raw_catheters$patient_id == pid)
      open <- rows[is.na(raw_catheters$pd_stop_date[rows])]
      if (length(open) > 0) {
        raw_catheters$pd_stop_date[open] <- tau
      }
      late <- rows[!is.na(raw_catheters$pd_stop_date[rows]) &
                     raw_catheters$pd_stop_date[rows] > tau]
      if (length(late) > 0) {
        log$add("Patient ", pid, ": catheter(s) ",
                paste(raw_catheters$catheter_id[late], collapse = ", "),
                " have a pd_stop_date after this patient's ",
                taus[[pid]]$reason, " on ", format(tau),
                "; clipped to that date for the remaining checks, correct the pd_stop_date in the source file.")
        raw_catheters$pd_stop_date[late] <- tau
      }
    }

    # a PD-to-HD transfer with no reason recorded is a gap in the source data
    if (identical(taus[[pid]]$reason, "permanent transfer to HD")) {
      detail <- taus[[pid]]$detail
      if (is.na(detail) || !nzchar(detail)) {
        log$add("Patient ", pid, " has an 'Any PD to HD' modality change on ",
                format(taus[[pid]]$date),
                " with no modality_change_reason.")
      }
    }

    # sa catheter "still active" is only true when nothing else gave a tau
    assumed <- if (is.na(tau)) {
      "they are being treated as if still active on PD."
    } else {
      paste0("they are being censored on ", format(tau), " (", taus[[pid]]$reason,
             ") instead.")
    }

    # a 'transplant' modality change with no date is a gap: the date can only come from transplant_date
    if (isTRUE(taus[[pid]]$transplant_gap)) {
      log$add("Patient ", pid, " has a 'transplant' modality change recorded ",
              "but no transplant_date supplied (and no catheter ",
              "removal_reason mentioning transplant); the transplant date is ",
              "unknown, so ", assumed,
              level = "warning")
    }

    # for 'Any PD to HD': the modality change was recorded the row is missing date_modality_change
    if (isTRUE(taus[[pid]]$hd_transfer_gap)) {
      log$add("Patient ", pid, " has an 'Any PD to HD' modality change ",
              "recorded but no date_modality_change supplied for it; the date ",
              "of the transfer is unknown, so ", assumed,
              level = "warning")
    }
  }


  # a prevalent patient's first episode just after t0 may be a relapse of an episode that is not in the file
  check_prior_episode_coverage(raw_pe_episodes, raw_catheters, t0, log)

  # episodes are matched to the catheter active on their date, catheters own their episodes, and patients own their catheters
  infections_by_catheter <- build_infections_by_catheter(raw_pe_episodes,
                                                         raw_catheters, log)
  built <- build_patient_list(pids, taus, raw_catheters, raw_patients,
                              infections_by_catheter, t0, t1, log)
  patient_list <- built$patient_list
  transfer_details <- built$transfer_details

  # flatten the object graph into the unit's three tibbles
  patients_tbl <- patients_to_tibble(patient_list, t0, t1, transfer_details)
  catheters_tbl <- catheters_to_tibble(patient_list, t0, t1)
  infections_tbl <- infections_to_tibble(patient_list, t0, t1)

  # unit-level numbers, cohort size: everyone on PD at any point in [t0, t1].
  n_patients <- length(patient_list)

  # incident patients: earliest PD start inside [t0, t1]
  n_new <- sum(vapply(patient_list, function(p) isTRUE(p$new_patient_flag),
                      logical(1)))

  # PY: total patient-years at risk, censored to [t0, t1] and each patient's tau
  tpyar <- total_patient_years(patient_list, t0, t1)

  # a gap in the source data is an error; the source files need correcting.
  report_issues(log)
  for (msg in log$get("warning")) {
    warning(msg, call. = FALSE)
  }

  x <- new_pd_unit(
    unit_id = unit_id,
    t0 = t0,
    t1 = t1,
    n_new = as.integer(n_new),
    n_patients = as.integer(n_patients),
    tpyar = tpyar,
    rate_benchmark = rate_benchmark,
    pf_benchmark = pf_benchmark,
    patients = patients_tbl,
    catheters = catheters_tbl,
    infections = infections_tbl,
    patient_list = patient_list
  )

  validate_pd_unit(x)
}




#' Print a pd_unit object
#'
#' A unit's headline snapshot: its name, the reporting period, the cohort size
#' with the incident count, how many catheters and peritonitis episodes it
#' holds, and its total patient-years at risk. Every episode in the unit is
#' counted here, including relapsing ones; \code{\link{summary.pd_unit}()}
#' reports the countable subset the peritonitis rate is built from.
#'
#' @param x A \code{pd_unit} object.
#' @param ... Ignored.
#'
#' @return \code{x}, invisibly.
#' @seealso \code{\link{summary.pd_unit}()} for the full indicator report.
#' @export
#'
#' @examples
#' \dontrun{
#' unit <- pd_unit(
#'   unit_data = system.file("extdata", "a3_2025.xlsx", package = "peridial"),
#'   infection_data = system.file("extdata", "pe_2025.xlsx", package = "peridial"),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
#'   unit_id = "Wellington PD Unit"
#' )
#' unit
#' }
#'
print.pd_unit <- function(x, ...) {
  cat("<pd_unit>", if (is.na(x$unit_id)) "(Unnamed unit)" else x$unit_id, "\n")
  cat("  Reporting period      : ", format(x$t0), " to ", format(x$t1), "\n", sep = "")
  cat("  Patients              : ", x$n_patients,
      " (", x$n_new, " incident)\n", sep = "")
  cat("  Catheters             : ", nrow(x$catheters), "\n", sep = "")
  cat("  Peritonitis episodes  : ", nrow(x$infections), "\n", sep = "")
  cat("  Total patient-years   : ", format(round(x$tpyar, 2), nsmall = 2), "\n", sep = "")
  invisible(x)
}



