
#' Create pd_patient object
#'
#' This represents a single unique person receiving PD at any point during the reporting period.
#' This patient owns a catheter or if having two or more catheters, non-overlapping catheters,
#' and each of these catheters in turn owns its own peritonitis episodes, giving the nested structure.
#'
#' @param patient_id Character. The patient's unique identifier (NHI).
#' @param catheters List. A list of \code{pd_catheter} objects belonging to
#'   this patient (i.e. each has \code{patient_id} equal to this patient's
#'   \code{patient_id}). Defaults to an empty list.
#' @param t0 Date. Start of the reporting period, used to derive
#'   \code{new_patient_flag}. Defaults to \code{NA}.
#' @param t1 Date. End of the reporting period. See \code{t0}.
#' @param gender Character. This patient's recorded gender, or \code{NA}.
#' @param ethnicity Character. This patient's recorded ethnicity, or
#'   \code{NA}.
#' @param date_of_birth Date. This patient's date of birth, or \code{NA}.
#'   Used to derive age.
#' @param primary_kidney_disease Character. The cause of this patient's kidney failure, or \code{NA}.
#' @param diabetes_status Character. This patient's recorded diabetes status
#'   (e.g. \code{"Type 1"}, \code{"Type 2"}, \code{"None"}), or \code{NA}.
#' @param smoking_status Character. This patient's recorded cigarette
#'   smoking status (e.g. \code{"Never"}, \code{"Former"},
#'   \code{"Current"}), or \code{NA}.
#' @param dialysis_type Character. The mode of PD therapy this patient
#'   uses -- \code{"APD"} (Automated PD), \code{"CAPD"} (Continuous
#'   Ambulatory PD), or \code{"Hybrid"} (both), or \code{NA}.
#' @param transfer_reason Character. Reason the patient left PD permanently:
#'   \code{"death"}, \code{"transplant"}, \code{"permanent transfer to HD"}, or
#'   \code{"pd stopped"} (every catheter has closed with none reopened, which
#'   \code{pd_unit()} applies only when \code{censor_on_last_stop = TRUE}).
#'   \code{NA} if they are still on PD. This together with
#'   \code{transfer_date} is the patient-level censoring point \eqn{tau}.
#' @param transfer_date Date. Date the patient left PD (\eqn{tau}). Required
#'   whenever \code{transfer_reason} is supplied, and vice versa.
#' @param new_patient_flag Logical. \code{TRUE} if this patient first started
#'   PD within \code{[t0, t1]} (incident), \code{FALSE} if PD start date is
#'   before \code{t0} (prevalent). Defaults to \code{NULL}, which derives it
#'   from the earliest \code{pd_start_date} across \code{catheters}.
#' @param n_catheters Integer. Number of catheters this patient has. Defaults
#'   to \code{NULL}, which derives it as \code{length(catheters)}.
#' @param n_episodes Integer. Count of countable (non-relapsing) peritonitis
#'   episodes across all of this patient's catheters within the reporting
#'   period. Defaults to \code{NULL}, which derives it by summing each
#'   catheter's \code{n_peritonitis_episodes}.
#'
#' @return An object of class \code{pd_patient}.
#' @export
#'
#' @examples
#' \dontrun{
#' # the unchecked constructor; pd_patient() is the one that validates
#' cath <- new_pd_catheter(
#'   patient_id = "ABC0110",
#'   catheter_id = "ABC0110_01",
#'   insertion_date = as.Date("2025-01-25"),
#'   procedure_type = "laparoscopic",
#'   pd_start_date = as.Date("2025-02-10"),
#'   pd_stop_date = as.Date(NA),
#'   removal_reason = NA_character_,
#'   infections = list(),
#'   t0 = as.Date("2025-01-01"),
#'   t1 = as.Date("2025-12-31"),
#'   total_exposure_days = 325L
#' )
#'
#' new_pd_patient(
#'   patient_id = "ABC0110",
#'   catheters = list(cath),
#'   t0 = as.Date("2025-01-01"),
#'   t1 = as.Date("2025-12-31"),
#'   gender = "Female",
#'   ethnicity = "NZ European",
#'   date_of_birth = as.Date("1968-04-12"),
#'   primary_kidney_disease = "Diabetic nephropathy",
#'   diabetes_status = "Type 2",
#'   smoking_status = "Former",
#'   dialysis_type = "APD",
#'   transfer_reason = NA_character_,
#'   transfer_date = as.Date(NA)
#' )}
#'
new_pd_patient <- function(patient_id = NA_character_,
                           catheters = list(),
                           t0 = as.Date(NA),
                           t1 = as.Date(NA),
                           gender = NA_character_,
                           ethnicity = NA_character_,
                           date_of_birth = as.Date(NA),
                           primary_kidney_disease = NA_character_,
                           diabetes_status = NA_character_,
                           smoking_status = NA_character_,
                           dialysis_type = NA_character_,
                           transfer_reason = NA_character_,
                           transfer_date = as.Date(NA),
                           new_patient_flag = NULL,
                           n_catheters = NULL,
                           n_episodes = NULL) {

  stopifnot(length(patient_id) == 1, is.character(patient_id) || is.na(patient_id))
  stopifnot(is.list(catheters))
  stopifnot(inherits(t0, "Date"), inherits(t1, "Date"))
  stopifnot(is.character(gender) || is.na(gender))
  stopifnot(is.character(ethnicity) || is.na(ethnicity))
  # allow a bare NA for date_of_birth too, same reasoning as transfer_date
  if (!inherits(date_of_birth, "Date") && length(date_of_birth) == 1 && is.na(date_of_birth)) {
    date_of_birth <- as.Date(NA)
  }
  stopifnot(inherits(date_of_birth, "Date"))
  stopifnot(is.character(primary_kidney_disease) || is.na(primary_kidney_disease))
  stopifnot(is.character(diabetes_status) || is.na(diabetes_status))
  stopifnot(is.character(smoking_status) || is.na(smoking_status))
  stopifnot(is.character(dialysis_type) || is.na(dialysis_type))
  stopifnot(is.character(transfer_reason) || is.na(transfer_reason))
  # If NA, coerces to as.Date(NA) for transfer_date
  if (!inherits(transfer_date, "Date") && length(transfer_date) == 1 && is.na(transfer_date)) {
    transfer_date <- as.Date(NA)
  }
  stopifnot(inherits(transfer_date, "Date"))

  # new_patient_flag / n_catheters / n_episodes are derived from `catheters` (and t0/t1)
  if (is.null(new_patient_flag)) {
    new_patient_flag <- is_incident_patient(catheters, t0, t1)
  }
  if (is.null(n_catheters)) {
    n_catheters <- length(catheters)
  }
  if (is.null(n_episodes)) {
    n_episodes <- count_patient_episodes(catheters)
  }

  stopifnot(length(new_patient_flag) == 1,
            is.na(new_patient_flag) || is.logical(new_patient_flag))
  stopifnot(length(n_catheters) == 1,
            is.na(n_catheters) || is.numeric(n_catheters))
  stopifnot(length(n_episodes) == 1,
            is.na(n_episodes) || is.numeric(n_episodes))

  structure(
    list(
      patient_id = patient_id,
      catheters = catheters,
      t0 = t0,
      t1 = t1,
      gender = gender,
      ethnicity = ethnicity,
      date_of_birth = date_of_birth,
      primary_kidney_disease = primary_kidney_disease,
      diabetes_status = diabetes_status,
      smoking_status = smoking_status,
      dialysis_type = dialysis_type,
      transfer_reason = transfer_reason,
      transfer_date = transfer_date,
      new_patient_flag = new_patient_flag,
      n_catheters = n_catheters,
      n_episodes = n_episodes
    ),
    class = "pd_patient"
  )
}


validate_pd_patient <- function(x) {
  stopifnot(inherits(x, "pd_patient"))

  if (is.na(x$patient_id)) {
    stop("patient_id must be supplied.")
  }
  # reporting period, if known, must be ordered sensibly
  if (!is.na(x$t0) && !is.na(x$t1) && x$t0 > x$t1) {
    stop("t0 must be on or before t1.")
  }
  # No transfer_reason (implied still on PD), but transfer_date supplied means invalid.
  # Reason needs to be supplied.
  if (is.na(x$transfer_reason) && !is.na(x$transfer_date)) {
    stop("transfer_date must be matched with a transfer_reason.")
  }
  # transfer_reason supplied but no date to go with it
  if (!is.na(x$transfer_reason) && is.na(x$transfer_date)) {
    stop("Missing date of transfer. Must be supplied.")
  }

  # Nested pd_catheter checks
  if (length(x$catheters) > 0) {
    for (i in seq_along(x$catheters)) {
      catheter <- x$catheters[[i]]

      if (!inherits(catheter, "pd_catheter")) {
        stop("catheters[[", i, "]] is not a pd_catheter object.")
      }
      if (!identical(catheter$patient_id, x$patient_id)) {
        stop("catheters[[", i, "]] has patient_id '", catheter$patient_id,
             "', which does not match this patient's patient_id '",
             x$patient_id, "'.")
      }
      # PD start is not optional; it is the origin of time-at-risk
      if (is.na(catheter$pd_start_date)) {
        stop("catheters[[", i, "]] has a missing pd_start_date. ", "Must be supplied.")
      }
      # pd_stop_date may be NA, but not missing
      if (length(catheter$pd_stop_date) != 1) {
        stop("catheters[[", i, "]] has no pd_stop_date (it may be NA ",
             "for an active catheter, but it must be present).")
      }
      # a patient's PD can't continue past their censoring date (tau): death, transplant, or permanent transfer to HD
      if (!is.na(x$transfer_date)) {
        if (catheter$pd_start_date > x$transfer_date) {
          stop("catheters[[", i, "]] has pd_start_date after this patient's transfer_date.")
        }
        if (is.na(catheter$pd_stop_date)) {
          stop("catheters[[", i, "]] has no pd_stop_date (still active), but ",
               "this patient permanently left PD on ", x$transfer_date,
               " ('", x$transfer_reason, "').")
        }
        if (catheter$pd_stop_date > x$transfer_date) {
          stop("catheters[[", i, "]] has pd_stop_date after this patient's ",
               "transfer_date (tau).")
        }
      }
      # the catheter's reporting window must be this patient's
      if (!identical(catheter$t0, x$t0) || !identical(catheter$t1, x$t1)) {
        stop("catheters[[", i, "]] has a reporting window that differs from ",
             "this patient's [t0, t1].")
      }
    }

    # catheter_ids must be unique within a patient
    cath_ids <- vapply(x$catheters, function(cath) cath$catheter_id, character(1))
    if (anyDuplicated(cath_ids) > 0) {
      stop("Duplicate catheter_id(s) within this patient: ",
           paste(unique(cath_ids[duplicated(cath_ids)]), collapse = ", "), ".")
    }

    # Check for non-overlapping catheter intervals. Two catheters may not deliver PD to the same patient at the same time.
    starts <- do.call(c, lapply(x$catheters, function(cath) cath$pd_start_date))
    stops  <- do.call(c, lapply(x$catheters, function(cath) cath$pd_stop_date))

    if (length(starts) > 1) {
      ord <- order(starts)
      starts <- starts[ord]
      stops <- stops[ord]
      ids <- cath_ids[ord]

      for (i in seq_len(length(starts) - 1)) {
        # an open-ended catheter can't be followed by another one
        if (is.na(stops[i])) {
          stop("Catheter '", ids[i], "' has no pd_stop_date (still active) ",
               "but catheter '", ids[i + 1], "' starts after it.",
               "Catheter intervals within a patient must not overlap.")
        }
        if (starts[i + 1] <= stops[i]) {
          stop("Catheters '", ids[i], "' and '", ids[i + 1], "' have ",
               "overlapping PD intervals. Catheter intervals within a ",
               "patient must not overlap.")
        }
      }
    }
  }

  # new_patient_flag / n_catheters / n_episodes must stay consistent with catheters (and t0/t1)
  expected_flag <- is_incident_patient(x$catheters, x$t0, x$t1)
  if (!is.na(x$new_patient_flag) && !is.na(expected_flag) &&
      !identical(x$new_patient_flag, expected_flag)) {
    stop("new_patient_flag does not match whether this patient's earliest ",
         "pd_start_date falls within [t0, t1].")
  }
  if (!is.na(x$n_catheters) && x$n_catheters != length(x$catheters)) {
    stop("n_catheters does not match length(catheters).")
  }
  expected_n <- count_patient_episodes(x$catheters)
  if (!is.na(x$n_episodes) && x$n_episodes != expected_n) {
    stop("n_episodes does not match the countable (non-relapsing) peritonitis ",
         "episodes across this patient's catheters within [t0, t1].")
  }
  x
}




#' Determine whether a patient is incident (new to PD) in a reporting period
#' @noRd
#'
is_incident_patient <- function(catheters,
                                t0 = as.Date(NA),
                                t1 = as.Date(NA)) {
  # no window supplied -> "incident within what?" is undecidable
  if (is.na(t0) && is.na(t1)) {
    return(NA)
  }
  if (length(catheters) == 0) {
    return(NA)
  }

  # identify start date
  starts <- lapply(catheters, function(cath) {
    # Checks if not a pd_catheter object or pd_start_date is NA
    if (!inherits(cath, "pd_catheter")) {
      return(NULL)
    }
    if (is.na(cath$pd_start_date)) {
      return(NULL)
    }
    cath$pd_start_date
  })
  # keep the date/s only in a list
  starts <- do.call(c, starts[!vapply(starts, is.null, logical(1))])

  # NA for when all catheters were invalid or had no start date and NULL-from-empty-list
  if (length(starts) == 0) {
    return(NA)
  }

  # earliest PD start across every valid pd_start_date this patient has
  first_start <- min(starts)

  in_window <- TRUE
  if (!is.na(t0)) in_window <- in_window && first_start >= t0
  if (!is.na(t1)) in_window <- in_window && first_start <= t1

  in_window
}



#' Count peritonitis episodes across all of patient's catheters
#'
#' Sums \code{n_peritonitis_episodes} over every \code{pd_catheter} in \code{catheters}.
#'
#' @param catheters List of \code{pd_catheter} objects for one patient.
#'
#' @return A single non-negative integer count.
#' @noRd
#'
count_patient_episodes <- function(catheters) {
  if (length(catheters) == 0) {
    return(0L)
  }

  counts <- vapply(catheters, function(cath) {
    if (!inherits(cath, "pd_catheter")) {
      return(0)
    }
    n <- cath$n_peritonitis_episodes
    if (is.null(n) || is.na(n)) {
      return(0)
    }
    as.numeric(n)
  }, numeric(1))

  sum(counts)
}





#' Construct and validate a pd_patient object
#'
#' Builds a \code{pd_patient} via \code{new_pd_patient()} and checks it with
#' \code{validate_pd_patient()} before returning it.
#'
#' @inheritParams new_pd_patient
#'
#' @return An object of class \code{pd_patient}.
#' @seealso \code{\link{new_pd_patient}()} for the unchecked constructor, and
#'   \code{vignette("data-structures", package = "peridial")}.
#' @export
#'
#' @examples
#' \dontrun{
#' inf <- pd_infection("ABC1234", as.Date("2025-03-01"), list("S. aureus"),
#'                     last_dose_antibiotic = as.Date("2025-03-15"))
#' cath <- pd_catheter(
#'   patient_id = "ABC1234", catheter_id = "ABC1234_01",
#'   insertion_date = as.Date("2024-12-01"), pd_start_date = as.Date("2024-12-15"),
#'   procedure_type = "Laparoscopic", infections = list(inf),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#' pat <- pd_patient(
#'   patient_id = "ABC1234", catheters = list(cath),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
#'   gender = "Female", date_of_birth = as.Date("1968-04-12"),
#'   dialysis_type = "APD"
#' )
#' pat
#' pat$new_patient_flag   # FALSE: PD started before t0, so prevalent
#'
#' # no catheter may run past the patient's censoring point
#' try(pd_patient(
#'   patient_id = "ABC1234", catheters = list(cath),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
#'   transfer_reason = "transplant", transfer_date = as.Date("2025-06-30")
#' ))
#' }
#'
pd_patient <- function(patient_id,
                       catheters = list(),
                       t0 = as.Date(NA),
                       t1 = as.Date(NA),
                       gender = NA_character_,
                       ethnicity = NA_character_,
                       date_of_birth = as.Date(NA),
                       primary_kidney_disease = NA_character_,
                       diabetes_status = NA_character_,
                       smoking_status = NA_character_,
                       dialysis_type = NA_character_,
                       transfer_reason = NA_character_,
                       transfer_date = as.Date(NA),
                       new_patient_flag = NULL,
                       n_catheters = NULL,
                       n_episodes = NULL) {
  x <- new_pd_patient(patient_id = patient_id,
                      catheters = catheters,
                      t0 = t0,
                      t1 = t1,
                      gender = gender,
                      ethnicity = ethnicity,
                      date_of_birth = date_of_birth,
                      primary_kidney_disease = primary_kidney_disease,
                      diabetes_status = diabetes_status,
                      smoking_status = smoking_status,
                      dialysis_type = dialysis_type,
                      transfer_reason = transfer_reason,
                      transfer_date = transfer_date,
                      new_patient_flag = new_patient_flag,
                      n_catheters = n_catheters,
                      n_episodes = n_episodes
                      )

  validate_pd_patient(x)
}



#' Print a pd_patient object
#'
#' A single patient's own snapshot: their id, reporting window, incident/
#' prevalent status, catheter and countable-episode counts, and whether
#' (and how) they were censored within the period.
#'
#' @param x A \code{pd_patient} object.
#' @param ... Ignored.
#'
#' @return \code{x}, invisibly.
#' @export
#'
#' @examples
#' \dontrun{
#' inf <- pd_infection("ABC1234", as.Date("2025-03-01"), list("S. aureus"),
#'                     last_dose_antibiotic = as.Date("2025-03-15"))
#' cath <- pd_catheter(
#'   patient_id = "ABC1234", catheter_id = "ABC1234_01",
#'   insertion_date = as.Date("2024-12-01"), pd_start_date = as.Date("2024-12-15"),
#'   procedure_type = "Laparoscopic", infections = list(inf),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#' pat <- pd_patient(
#'   patient_id = "ABC1234", catheters = list(cath),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
#'   gender = "Female", date_of_birth = as.Date("1968-04-12"),
#'   dialysis_type = "APD"
#' )
#' pat
#' }
#'
print.pd_patient <- function(x, ...) {
  cat("<pd_patient>", if (is.na(x$patient_id)) "(unknown id)" else x$patient_id, "\n")
  cat("  Reporting window     : ", format(x$t0), " to ", format(x$t1), "\n", sep = "")
  cat("  Status               : ",
      if (is.na(x$new_patient_flag)) "unknown" else if (x$new_patient_flag) "incident" else "prevalent",
      "\n", sep = "")
  cat("  Catheters            : ", x$n_catheters, "\n", sep = "")
  cat("  Peritonitis          : ", x$n_episodes, "\n", sep = "")
  if (is.na(x$transfer_reason)) {
    cat("  Censoring          : still active on PD\n", sep = "")
  } else {
    cat("  Censoring          : ", x$transfer_reason, " on ", format(x$transfer_date), "\n", sep = "")
  }
  invisible(x)
}



#' Summarise a pd_patient object
#'
#' A single patient's clinical snapshot: reporting window, incident/
#' prevalent status, each catheter's active window and outcome (with that
#' catheter's own countable peritonitis episodes), this patient's total time-at-risk
#' within \code{[t0, t1]}, a breakdown of countable peritonitis episodes by \code{episode_type}
#' across every catheter, and how (or whether) this patient was censored.
#'
#' @param object A \code{pd_patient} object.
#' @param ... Ignored.
#'
#' @return Invisibly, a list with components \code{status}, \code{age_years}
#'   (age at \code{t1}, the reporting-window end), \code{catheters}
#'   (a data frame with one row per catheter), \code{total_exposure_days},
#'   \code{total_exposure_years}, \code{n_episodes}, and \code{episode_types}
#'   (a table of countable-episode counts by \code{episode_type}). Unlike
#'   \code{\link{summary.pd_unit}()}'s \code{episode_types}, which counts every
#'   episode, this counts only those that tell towards the rate.
#' @seealso \code{\link{summary.pd_unit}()} for the whole cohort, and
#'   \code{vignette("peridial", package = "peridial")}.
#' @export
#'
#' @examples
#' \dontrun{
#' inf <- pd_infection("ABC1234", as.Date("2025-03-01"), list("S. aureus"),
#'                     last_dose_antibiotic = as.Date("2025-03-15"))
#' cath <- pd_catheter(
#'   patient_id = "ABC1234", catheter_id = "ABC1234_01",
#'   insertion_date = as.Date("2024-12-01"), pd_start_date = as.Date("2024-12-15"),
#'   procedure_type = "Laparoscopic", infections = list(inf),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#' pat <- pd_patient(
#'   patient_id = "ABC1234", catheters = list(cath),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
#'   gender = "Female", date_of_birth = as.Date("1968-04-12"),
#'   dialysis_type = "APD"
#' )
#' s <- summary(pat)
#' s$total_exposure_years
#' s$episode_types
#' }
#'
summary.pd_patient <- function(object, ...) {
  x <- object

  # pads a label to column 20 so every ":" lines up
  pad <- function(label) sprintf("%-19s:", label)

  status <- if (is.na(x$new_patient_flag)) {
    "unknown"
  } else if (isTRUE(x$new_patient_flag)) {
    "incident"
  } else {
    "prevalent"
  }

  # this patient's own censoring point (tau) used to cap exposure days
  tau <- x$transfer_date
  if (is.null(tau)) tau <- as.Date(NA)

  # per-catheter exposure within [t0, t1], censored at tau
  total_days <- if (length(x$catheters) == 0) {
    0
  } else {
    sum(vapply(x$catheters, catheter_exposure_days, numeric(1),
               t0 = x$t0, t1 = x$t1, tau = tau))
  }
  total_years <- total_days / 365.25

  # Countable infections per catheter (n_episodes). returns the infection objects
  countable_infections_of <- function(cath) {
    if (length(cath$infections) == 0) {
      return(list())
    }
    countable <- vapply(cath$infections, function(inf) {
      count_episodes(list(inf), x$t0, x$t1,    # each infection is re-checked with count_episodes() to match with n_episodes
                    cath$pd_start_date, cath$pd_stop_date, tau = tau) > 0
    }, logical(1))
    cath$infections[countable]
  }
  all_countable <- unlist(lapply(x$catheters, countable_infections_of),
                          recursive = FALSE, use.names = FALSE)
  all_types <- vapply(all_countable, function(inf) {
    if (is.na(inf$episode_type)) "uncategorised" else inf$episode_type
  }, character(1))
  episode_types <- table(if (length(all_types) == 0) character(0) else all_types)

  fmt_field <- function(v) if (is.na(v)) "unknown" else v

  # age at t1 (reporting-window end)
  age_years <- if (is.na(x$date_of_birth) || is.na(x$t1)) {
    NA_real_
  } else {
    as.numeric(difftime(x$t1, x$date_of_birth, units = "days")) / 365.25
  }
  age_str <- if (is.na(age_years)) "unknown" else sprintf("%.0f (at t1)", age_years)

  cat("<summary.pd_patient>", if (is.na(x$patient_id)) "(unknown id)" else x$patient_id, "\n")
  cat("  ", pad("Reporting window"), " ", format(x$t0), " to ", format(x$t1), "\n", sep = "")
  cat("  ", pad("Status"), " ", status, "\n", sep = "")
  cat("  ", pad("Age"), " ", age_str, "\n", sep = "")
  cat("  ", pad("Gender"), " ", fmt_field(x$gender), "\n", sep = "")
  cat("  ", pad("Ethnicity"), " ", fmt_field(x$ethnicity), "\n", sep = "")
  cat("  ", pad("Kidney disease"), " ", fmt_field(x$primary_kidney_disease), "\n", sep = "")
  cat("  ", pad("Diabetes"), " ", fmt_field(x$diabetes_status), "\n", sep = "")
  cat("  ", pad("Smoking status"), " ", fmt_field(x$smoking_status), "\n", sep = "")
  cat("  ", pad("Dialysis type"), " ", fmt_field(x$dialysis_type), "\n", sep = "")
  cat("  ", pad(paste0("Catheters (", length(x$catheters), ")")), "\n", sep = "")
  for (cath in x$catheters) {
    end_str <- if (is.na(cath$pd_stop_date)) {
      "(active)"
    } else {
      paste0(format(cath$pd_stop_date),
             if (!is.na(cath$removal_reason)) {
               paste0(" (removed, ", cath$removal_reason, ")")
             } else {
               ""
             })
    }
    cat("    ", cath$catheter_id, " : inserted ", format(cath$insertion_date),
        ", PD ", format(cath$pd_start_date), " to ", end_str,
        "\n", sep = "")

    cath_infections <- countable_infections_of(cath)
    if (length(cath_infections) == 0) {
      cat("        (no countable peritonitis episodes for this catheter)\n")
    } else {
      for (inf in cath_infections) {
        organisms <- paste(unlist(inf$organism_list), collapse = ", ")
        type_label <- if (is.na(inf$episode_type)) "uncategorised" else inf$episode_type
        cat("        - ", format(inf$infection_date), " : ", organisms,  "\n", sep = "")
      }
    }
  }
  cat("  ", pad("Total exposure"), " ", total_days, " days (",
      sprintf("%.2f", total_years), " patient-years)\n", sep = "")
  type_str <- if (length(all_types) == 0) {
    ""
  } else {
    paste0(" (", paste(sprintf("%d %s", episode_types, names(episode_types)),
                       collapse = ", "), ")")
  }
  cat("  ", pad("Peritonitis history"), " ", length(all_types), " countable episode",
      if (length(all_types) == 1) "" else "s", type_str, "\n",
      sep = "")
  invisible(list(
    status = status,
    age_years = age_years,
    catheters = data.frame(
      catheter_id = vapply(x$catheters, function(c) c$catheter_id, character(1)),
      pd_start_date = if (length(x$catheters) == 0) {
        as.Date(character(0))
      } else {
        do.call(c, lapply(x$catheters, function(c) c$pd_start_date))
      },
      pd_stop_date = if (length(x$catheters) == 0) {
        as.Date(character(0))
      } else {
        do.call(c, lapply(x$catheters, function(c) c$pd_stop_date))
      },
      removal_reason = vapply(x$catheters, function(c) as.character(c$removal_reason),
                              character(1)),
      stringsAsFactors = FALSE
    ),
    total_exposure_days = total_days,
    total_exposure_years = total_years,
    n_episodes = length(all_types),
    episode_types = episode_types
  ))
}



## SUBSET METHOD ##

#' Subset a pd_patient object
#'
#' Returns the rows and, (with \code{select}), the columns of one patient's
#' data that meet a condition, as a plain tibble. Peritonitis indicators are not
#' recalculated and the patient is not modified.
#'
#' The table is the one \code{\link{subset.pd_unit}()} uses, for this patient
#' alone. A patient with no catheters, or with no episodes, still gives a row,
#' with the columns below that level left \code{NA}. To subset several patients
#' at once, use \code{\link{subset.pd_unit}()} and filter on
#' \code{patient_id}.
#'
#' @param x A \code{pd_patient} object.
#' @param subset A logical condition on the columns of the table. Omit to
#'   keep every row.
#' @param select Which columns to return, as in \code{\link[base]{subset}()}.
#'   Omit to keep every column.
#' @param ... Ignored.
#'
#' @return A tibble.
#' @seealso \code{\link{subset.pd_unit}()}, \code{\link{subset.pd_catheter}()}.
#' @export
#'
#' @examples
#' \dontrun{
#' cath <- new_pd_catheter(
#'   patient_id = "ABC0110", catheter_id = "ABC0110_01",
#'   insertion_date = as.Date("2024-12-01"), pd_start_date = as.Date("2024-12-15"),
#'   procedure_type = "laparoscopic",
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#' pat <- new_pd_patient(
#'   patient_id = "ABC0110", catheters = list(cath), gender = "Female",
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#' subset(pat, procedure_type == "laparoscopic",
#'        select = c(patient_id, gender, catheter_id, procedure_type))
#'}
#'
subset.pd_patient <- function(x, subset, select, ...) {
  if (...length() > 0L) {
    stop("Unused argument(s) passed to subset(). A pd_patient takes only a ",
         "condition and `select`.")
  }

  # transfer_detail is held only on the unit's tibble, transfer_detail filed not in pd_patient object
  patients_tbl <- patients_to_tibble(list(x), x$t0, x$t1)
  patients_tbl <- patients_tbl[setdiff(names(patients_tbl), "transfer_detail")]

  flat <- flatten_pd_tables(patients_tbl,
                            catheters_to_tibble(list(x), x$t0, x$t1),
                            infections_to_tibble(list(x), x$t0, x$t1))
  subset_table(flat, rlang::enquo(subset), rlang::enquo(select))
}
