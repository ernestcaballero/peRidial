

#' Create pd_catheter object
#'
#' A single PD catheter episode for a patient: when it was inserted,
#' the window of active PD therapy, and (if applicable) why and
#' when it was removed. This object owns the peritonitis episodes that
#' occurred during this catheter's active PD window.
#'
#' @param patient_id Character. The patient's unique identifier (NHI).
#' @param catheter_id Character. Unique identifier for this catheter. Generated as per
#'    insertion date per patient (e.g. XYZ1234_01).
#' @param insertion_date Date. Date the catheter was surgically inserted.
#' @param procedure_type Character. Type of insertion technique, as recorded on
#'    the A3 form: \code{"Surgical"}, \code{"Laparoscopic"} or
#'    \code{"Percutaneous"}.
#' @param pd_start_date Date. Date of start of PD therapy of this catheter, usually 2-4 weeks after insertion.
#' @param pd_stop_date Date. Date PD therapy stopped on this catheter, or
#'   \code{NA} if the catheter is still in active use.
#' @param removal_reason Character. Reason PD on this catheter stopped, or
#'   \code{NA} if it has not. One of the accepted reasons the package
#'   recognises (the ISPD removal reasons such as
#'   \code{"Acute Peritonitis"}, \code{"Catheter Block"} or
#'   \code{"Dialysate Leak"}, plus \code{"Death"}, \code{"Transplant"} and
#'   \code{"Permanent transfer to HD"}); a value that is not on the list is
#'   read as \code{"Other"}, and a blank one as \code{NA}.
#' @param infections List. A list of \code{pd_infection} objects that occurred
#'   on this catheter. An episode belongs to a catheter by containment because
#'   a \code{pd_infection} has no \code{catheter_id} field. Each one need
#'   only carry the same \code{patient_id} as this catheter, and fall inside its PD window.
#'   Defaults to an empty list for a catheter with no recorded peritonitis episodes.
#' @param t0 Date. Start of the reporting period, used (together with
#'   \code{t1}, \code{pd_start_date}, and \code{pd_stop_date} -- see
#'   \code{count_episodes()}) to scope \code{n_peritonitis_episodes}/\code{peritonitis_flag}
#'   to episodes falling inside this catheter's active window \emph{and} the reporting
#'   period. Defaults to \code{NA}, which leaves that side of the window
#'   unfiltered.
#' @param t1 Date. End of the reporting period. Used with \code{t0} (together with
#'   \code{t1}, \code{pd_start_date}, and \code{pd_stop_date} -- see
#'   \code{count_episodes()}) to scope \code{n_peritonitis_episodes}/\code{peritonitis_flag}
#'   to episodes falling inside this catheter's active window \emph{and} the reporting
#'   period. Defaults to \code{NA}, which leaves that side of the window
#'   unfiltered.
#' @param total_exposure_days Integer. Known as patient-time-at-risk. The total days
#'   this catheter is at risk for peritonitis (censored against \code{t0}, \code{t1},
#'   and the patient's censoring date \code{tau} for death, transplant, or permanent HD transfer).
#'   ISPD 2022 defines patient-time-at-risk as beginning on the day PD commences and continuing while
#'   the patient remains on PD. \code{pd_unit()} supplies this number, and it equals
#'   \code{exposure_days_in_period} on the unit's catheters tibble.
#'   Defaults to \code{NA_integer_} for a catheter built by hand.
#' @param n_peritonitis_episodes Integer. Count of peritonitis episodes that
#'   occurred on this catheter within its active window
#'   (\code{pd_start_date}/\code{pd_stop_date}) and the reporting period
#'   (\code{t0}/\code{t1}) -- 0, 1, 2, etc. See \code{count_episodes()}
#'   for how that active window is derived. Relapsing episodes are excluded
#'   from this count; recurrent/repeat episodes and \code{NA_character_} are included.
#' @param peritonitis_flag Logical. \code{TRUE} if \code{n_peritonitis_episodes > 0}
#'   for this catheter within that window, \code{FALSE} otherwise.
#'
#' @return An object of class \code{pd_catheter}.
#' @export
#'
#' @examples
#' \dontrun{
#' # the unchecked constructor; pd_catheter() is the one that validates
#' new_pd_catheter(
#'   patient_id = "ABC0110",
#'   catheter_id = "ABC0110_01",
#'   insertion_date = as.Date("2025-01-25"),
#'   procedure_type = "laparoscopic",
#'   pd_start_date = as.Date("2025-02-10"),
#'   pd_stop_date = as.Date(NA),
#'   removal_reason = NA_character_,
#'   infections = list(),
#'   t0 = as.Date("2025-01-01"),
#'   t1 = as.Date("2025-12-31"),
#'   total_exposure_days = 324L
#' )}
#'
new_pd_catheter <- function(patient_id = NA_character_,
                            catheter_id = NA_character_,
                            insertion_date = as.Date(NA),
                            procedure_type = NA_character_,
                            pd_start_date = as.Date(NA),
                            pd_stop_date = as.Date(NA),
                            removal_reason = NA_character_,
                            infections = list(),
                            t0 = as.Date(NA),
                            t1 = as.Date(NA),
                            total_exposure_days = NA_integer_,
                            n_peritonitis_episodes = NULL,
                            peritonitis_flag = NULL) {

  stopifnot(length(patient_id) == 1, is.character(patient_id) || is.na(patient_id))
  stopifnot(length(catheter_id) == 1, is.character(catheter_id) || is.na(catheter_id))
  stopifnot(inherits(insertion_date, "Date"))
  stopifnot(is.character(procedure_type) || is.na(procedure_type))
  if (!inherits(pd_start_date, "Date")) {
    stop("pd_start_date must be a Date. If PD therapy hasn't started yet, use as.Date(NA) rather than NA.")
  }

  if (!inherits(pd_stop_date, "Date")) {
    stop("pd_stop_date must be a Date. If the catheter is still active (no stop date), use as.Date(NA) rather than NA.")
  }
  stopifnot(is.character(removal_reason) || is.na(removal_reason))
  stopifnot(is.list(infections))
  stopifnot(inherits(t0, "Date"), inherits(t1, "Date"))
  stopifnot(length(total_exposure_days) == 1,
            is.na(total_exposure_days) || is.numeric(total_exposure_days))

  # n_peritonitis_episodes / peritonitis_flag count episodes within the survey period [t0, t1]
  if (is.null(n_peritonitis_episodes)) {
    n_peritonitis_episodes <- count_episodes(infections, t0, t1, pd_start_date, pd_stop_date)
  }
  if (is.null(peritonitis_flag)) {
    peritonitis_flag <- n_peritonitis_episodes > 0
  }

  stopifnot(length(n_peritonitis_episodes) == 1,
            is.na(n_peritonitis_episodes) || is.numeric(n_peritonitis_episodes))
  stopifnot(length(peritonitis_flag) == 1,
            is.na(peritonitis_flag) || is.logical(peritonitis_flag))

  structure(
    list(
      patient_id = patient_id,
      catheter_id = catheter_id,
      insertion_date = insertion_date,
      procedure_type = procedure_type,
      pd_start_date = pd_start_date,
      pd_stop_date = pd_stop_date,
      removal_reason = removal_reason,
      infections = infections,
      t0 = t0,
      t1 = t1,
      total_exposure_days = total_exposure_days,
      n_peritonitis_episodes = n_peritonitis_episodes,
      peritonitis_flag = peritonitis_flag
    ),
    class = "pd_catheter"
  )
}


validate_pd_catheter <- function(x) {
  stopifnot(inherits(x, "pd_catheter"))

  if (is.na(x$patient_id) || is.na(x$catheter_id)) {
    stop("Both patient_id and catheter_id must be supplied.")
  }
  if (is.na(x$insertion_date)) {
    stop("Missing insertion_date. Must be supplied.")
  }
  if (is.na(x$pd_start_date)) {
    stop("Missing pd_start_date. Must be supplied.")
  }
  # a catheter can't start PD therapy before it's actually been inserted
  if (x$insertion_date > x$pd_start_date) {
    stop("insertion_date must be on or before pd_start_date.")
  }
  # if PD therapy has stopped, the start/stop window must make sense
  if (!is.na(x$pd_stop_date) && x$pd_start_date > x$pd_stop_date) {
    stop("pd_start_date must be on or before pd_stop_date.")
  }
  # a removal_reason means the catheter has actually stopped being used
  if (!is.na(x$removal_reason) && is.na(x$pd_stop_date)) {
    stop("pd_stop_date must be supplied when removal_reason is given.")
  }

  # # ALREADY IN pd_unit.R
  # # reporting period, if known, must be ordered sensibly
  # if (!is.na(x$t0) && !is.na(x$t1) && x$t0 > x$t1) {
  #   stop("t0 must be on or before t1.")
  # }

  # total_exposure_days, if known, can't be negative, and can't exceed the raw exposure days
  # the catheter was actually open for, further censored against t0/t1/tau if no stop date.
  if (!is.na(x$total_exposure_days)) {
    if (x$total_exposure_days < 0) {
      stop("total_exposure_days cannot be negative.")
    }
    if (!is.na(x$pd_stop_date)) {
      raw_exposure_days <- as.numeric(x$pd_stop_date - x$pd_start_date + 1)
      if (x$total_exposure_days > raw_exposure_days) {
        stop("total_exposure_days cannot exceed the span between pd_start_date and pd_stop_date.")
      }
    } else if (!is.na(x$t1)) {
      raw_exposure_days <- as.numeric(x$t1 - x$pd_start_date + 1)
      if (x$total_exposure_days > raw_exposure_days) {
        stop("total_exposure_days cannot exceed the span between pd_start_date and the reporting period's end t1.")
      }
    }
  }

  # Nested infection checks
  if (length(x$infections) > 0) {
    for (i in seq_along(x$infections)) {
      infection <- x$infections[[i]]

      if (!inherits(infection, "pd_infection")) {
        stop("infections[[", i, "]] is not a pd_infection object.")
      }
      # checks if patient_id in pd_infection and pd_catheter matches
      if (!identical(infection$patient_id, x$patient_id)) {
        stop("infections[[", i, "]] has patient_id '", infection$patient_id,
             "', which does not match this catheter's patient_id '", x$patient_id, "'.")
      }
      # infection_date is required before the window checks below
      if (is.na(infection$infection_date)) {
        stop("infections[[", i, "]] has a missing infection_date. ",
             "Must be supplied.")
      }
      # ISPD time-at-risk begins on pd_start_date, so an episode can't be before this date,
      # If the catheter has stopped, an episode can't be after pd_stop_date either.
      if (infection$infection_date < x$pd_start_date) {
        stop("infections[[", i, "]] has infection_date before this ",
             "catheter's pd_start_date.")
      }
      if (!is.na(x$pd_stop_date) && infection$infection_date > x$pd_stop_date) {
        stop("infections[[", i, "]] has infection_date after this ",
             "catheter's pd_stop_date.")
      }
    }
  }

  # n_peritonitis_episodes / peritonitis_flag must stay consistent with
  # infections within this catheter's active window
  expected_n <- count_episodes(x$infections, x$t0, x$t1, x$pd_start_date, x$pd_stop_date)
  if (!is.na(x$n_peritonitis_episodes) && x$n_peritonitis_episodes != expected_n) {
    stop("n_peritonitis_episodes does not match the number of infections ",
         "falling within this catheter's active window and [t0, t1].")
  }
  if (!is.na(x$peritonitis_flag) &&
      !identical(x$peritonitis_flag, expected_n > 0)) {
    stop("peritonitis_flag does not match whether any infection falls ",
         "within this catheter's active window and [t0, t1].")
  }

  x
}




#' Count peritonitis episodes falling inside a reporting period
#'
#' Counts how many \code{pd_infection} objects in
#' \code{infections} both (a) have an \code{infection_date} inside this
#' catheter's own active window, and (b) are not a \strong{relapsing} episode.
#' Per ISPD, a relapsing episode (same organism, occurring within 4 weeks of
#' completing antibiotics for the immediately preceding episode)
#' see \code{\link{get_episode_type}()}) is a continuation of that
#' prior episode rather than a distinct new episode, so it is excluded from the
#' count used for rate/free-percentage calculations. \code{"recurrent"} and
#' \code{"repeat"} episodes are distinct new episodes and stay counted,
#' as does an episode with \code{NA} \code{episode_type} (e.g. a patient's
#' first-ever recorded episode, with nothing prior to compare against).
#'
#' The active window is \code{[lower, upper]}, where:
#' \itemize{
#'   \item \code{lower} is \code{pd_start_date}, raised to \code{t0} if the
#'     catheter's PD therapy started before the reporting period began.
#'   \item \code{upper} is the earliest of \code{pd_stop_date},
#'     \code{t1} and \code{tau}, using whichever of them are supplied. An
#'     episode after the end of the reporting period, or after the patient
#'     permanently left PD, is therefore never counted, even if the catheter's
#'     own \code{pd_stop_date} is later. This is the same upper bound that
#'     \code{catheter_exposure_days()} uses for the denominator, so the
#'     numerator and the patient-years cover the same time.
#' }
#'
#' Any of \code{t0}/\code{t1}/\code{pd_start_date}/\code{pd_stop_date}/\code{tau}
#' can be \code{NA}; a missing bound is simply left unfiltered on that side. If all
#' five are \code{NA} this only filters out relapses.
#'
#' @param infections List of \code{pd_infection} objects.
#' @param t0 Date. Start of the reporting period, or \code{NA}.
#' @param t1 Date. End of the reporting period, or \code{NA}.
#' @param pd_start_date Date. This catheter's own PD start date, or
#'   \code{NA}.
#' @param pd_stop_date Date. This catheter's own PD stop date, or \code{NA}
#'   if it is still active.
#' @param tau Date. The date the patient permanently left PD (death,
#'   transplant or permanent transfer to HD), or \code{NA} (the default) if they
#'   did not, or if it is not known. Episodes after \code{tau} are not counted.
#'
#' @return A single non-negative integer count.
#' @seealso \code{\link{catheter_exposure_days}()}, which uses the same upper
#'   bound for the denominator, and
#'   \code{vignette("indicators-classification", package = "peridial")}.
#' @export
#'
#' @examples
#' \dontrun{
#' episode <- function(date) {
#'   pd_infection("ABC1234", as.Date(date), list("E. coli"),
#'                last_dose_antibiotic = as.Date(date) + 14)
#' }
#' infections <- list(episode("2025-12-20"), episode("2026-01-20"))
#'
#' # the catheter runs on into February 2026, but the reporting period ends on
#' # 31 December 2025, so only the first episode counts
#' count_episodes(infections,
#'                t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
#'                pd_start_date = as.Date("2025-03-01"),
#'                pd_stop_date = as.Date("2026-02-15"))
#' }
#'
count_episodes <- function(infections,
                          t0 = as.Date(NA),
                          t1 = as.Date(NA),
                          pd_start_date = as.Date(NA),
                          pd_stop_date = as.Date(NA),
                          tau = as.Date(NA)) {
  if (length(infections) == 0) {
    return(0L)
  }

  # Lower bound
  lower <- pd_start_date
  if (!is.na(t0) && (is.na(lower) || t0 > lower)) {
    lower <- t0
  }

  # Upper bound: the earliest of the catheter's stop date, the end of the period and tau
  bounds <- c(pd_stop_date, t1, tau)
  upper <- if (all(is.na(bounds))) as.Date(NA) else min(bounds, na.rm = TRUE)

  counts <- vapply(infections, function(inf) {
    if (!inherits(inf, "pd_infection")) {
      return(FALSE)
    }
    # Infection counter
    in_window <- TRUE

    # Checks if episode is on or after the lower bound, on or before the upper bound
    if (!is.na(lower)) in_window <- in_window && inf$infection_date >= lower
    if (!is.na(upper)) in_window <- in_window && inf$infection_date <= upper

    # ISPD: a relapsing episode is a continuation of the preceding episode,
    # not a new one, so exclude it from the count. Recurrent/repeat/NA episodes are counted.
    not_relapse <- is.na(inf$episode_type) || inf$episode_type != "relapsing"

    in_window && not_relapse
  }, logical(1))

  sum(counts)
}




#' Construct and validate a pd_catheter object
#'
#' Builds a \code{pd_catheter} via \code{new_pd_catheter()} and checks it with
#' \code{validate_pd_catheter()} before returning it.
#'
#' @inheritParams new_pd_catheter
#'
#' @return An object of class \code{pd_catheter}.
#' @seealso \code{\link{new_pd_catheter}()} for the unchecked constructor, and
#'   \code{vignette("data-structures", package = "peridial")}.
#' @export
#'
#' @examples
#' \dontrun{
#' inf <- pd_infection(
#'   patient_id = "ABC1234",
#'   infection_date = as.Date("2025-03-01"),
#'   organism_list = list("S. aureus"),
#'   last_dose_antibiotic = as.Date("2025-03-15")
#' )
#'
#' pd_catheter(
#'   patient_id = "ABC1234",
#'   catheter_id = "ABC1234_01",
#'   insertion_date = as.Date("2024-12-01"),
#'   procedure_type = "Laparoscopic",
#'   pd_start_date = as.Date("2024-12-15"),
#'   infections = list(inf),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#'
#' # an episode dated before this catheter's PD window cannot belong to it
#' too_early <- pd_infection("ABC1234", as.Date("2024-10-01"), list("E. coli"),
#'                           last_dose_antibiotic = as.Date("2024-10-15"))
#' try(pd_catheter(
#'   patient_id = "ABC1234", catheter_id = "ABC1234_01",
#'   insertion_date = as.Date("2024-11-02"), pd_start_date = as.Date("2024-11-20"),
#'   infections = list(too_early),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' ))
#' }
#'
pd_catheter <- function(patient_id,
                        catheter_id,
                        insertion_date,
                        procedure_type = NA_character_,
                        pd_start_date,
                        pd_stop_date = as.Date(NA),
                        removal_reason = NA_character_,
                        infections = list(),
                        t0 = as.Date(NA),
                        t1 = as.Date(NA),
                        total_exposure_days = NA_integer_,
                        n_peritonitis_episodes = NULL,
                        peritonitis_flag = NULL) {
  x <- new_pd_catheter(patient_id = patient_id,
                       catheter_id = catheter_id,
                       insertion_date = insertion_date,
                       procedure_type = procedure_type,
                       pd_start_date = pd_start_date,
                       pd_stop_date = pd_stop_date,
                       removal_reason = removal_reason,
                       infections = infections,
                       t0 = t0,
                       t1 = t1,
                       total_exposure_days = total_exposure_days,
                       n_peritonitis_episodes = n_peritonitis_episodes,
                       peritonitis_flag = peritonitis_flag
                       )

  validate_pd_catheter(x)
}




#' Print a pd_catheter object
#'
#' A single catheter's snapshot: the reporting window, \code{catheter_id},
#' \code{insertion_date}, \code{procedure_type}, the PD window, and the
#' countable peritonitis episode count within that window
#' (\code{n_peritonitis_episodes}). Each countable episode is then listed with
#' its \code{infection_date}, \code{episode_type} (if any) and \code{outcome}
#' (if any), followed by any relapsing episodes, shown separately because they
#' do not count towards \code{n_peritonitis_episodes} (see
#' \code{\link{count_episodes}()}).
#'
#' @param x A \code{pd_catheter} object.
#' @param ... Ignored.
#'
#' @return \code{x}, invisibly.
#' @export
#'
#' @examples
#' \dontrun{
#' inf <- pd_infection("ABC1234", as.Date("2025-03-01"), list("S. aureus"),
#'                     last_dose_antibiotic = as.Date("2025-03-15"))
#' cath <- pd_catheter(
#'   patient_id = "ABC1234", catheter_id = "ABC1234_01",
#'   insertion_date = as.Date("2024-12-01"), pd_start_date = as.Date("2024-12-15"),
#'   procedure_type = "Laparoscopic", infections = list(inf),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#' cath
#' }
#'
print.pd_catheter <- function(x, ...) {
  cat("<pd_catheter>", if (is.na(x$patient_id)) "(unknown patient)" else x$patient_id, "\n")
  cat("  Reporting window   : ", format(x$t0), " to ", format(x$t1), "\n", sep = "")
  cat("  Catheter           : ", if (is.na(x$catheter_id)) "(unknown id)" else x$catheter_id, "\n", sep = "")
  cat("  Inserted           : ", format(x$insertion_date), "\n", sep = "")
  cat("  Procedure type     : ", if (is.na(x$procedure_type)) "(unknown)" else x$procedure_type, "\n", sep = "")
  end_str <- if (is.na(x$pd_stop_date)) {
    "(active)"
  } else {
    paste0(format(x$pd_stop_date),
           if (!is.na(x$removal_reason)) paste0(" (removed, ", x$removal_reason, ")") else "")
  }
  cat("  PD window          : ", format(x$pd_start_date), " to ", end_str, "\n", sep = "")

  cat("  Peritonitis        : ", x$n_peritonitis_episodes,
      "\n", sep = "")

  # describes one infection as "date (episode_type, outcome: outcome)", drop episode_type/outcome when they're NA
  describe_episode <- function(inf) {
    details <- character(0)
    if (!is.na(inf$episode_type)) details <- c(details, inf$episode_type)
    if (!is.na(inf$outcome)) details <- c(details, paste0("outcome: ", inf$outcome))
    if (length(details) == 0) {
      format(inf$infection_date)
    } else {
      paste0(format(inf$infection_date), " (", paste(details, collapse = ", "), ")")
    }
  }

  # countable episodes
  countable <- vapply(x$infections, function(inf) {
    count_episodes(list(inf), x$t0, x$t1, x$pd_start_date, x$pd_stop_date) > 0
  }, logical(1))
  countable_infections <- x$infections[countable]
  if (length(countable_infections) > 0) {
    cat("    Episodes                : ",
        paste(vapply(countable_infections, describe_episode, character(1)), collapse = "; "),
        "\n", sep = "")
  }

  # show relapsing peritonitis
  relapses <- Filter(function(inf) identical(inf$episode_type, "relapsing"), x$infections)
  if (length(relapses) > 0) {
    cat("    Not countable (relapse) : ",
        paste(vapply(relapses, describe_episode, character(1)), collapse = "; "),
        "\n", sep = "")
  }

  invisible(x)
}




## SUBSET METHOD ##

#' Subset a pd_catheter object
#'
#' Returns the rows (and, with \code{select}, the columns) of one catheter's
#' data that meet a condition, as a plain tibble. Peritonitis indicators are not
#' recalculated and the catheter is not modified.
#'
#' The table is the one \code{\link{subset.pd_unit}()} uses, for this catheter
#' alone. A catheter with no episodes gives a single row whose episode columns
#' are \code{NA}. To subset several catheters at once,
#' use \code{\link{subset.pd_unit}()} and filter on \code{catheter_id}.
#'
#' @param x A \code{pd_catheter} object.
#' @param subset A logical condition on the columns of the table. Omit to
#'   keep every row.
#' @param select Which columns to return, as in \code{\link[base]{subset}()}.
#'   Omit to keep every column.
#' @param ... Ignored.
#'
#' @return A tibble.
#' @seealso \code{\link{subset.pd_unit}()}, \code{\link{subset.pd_patient}()}.
#' @export
#'
#' @examples
#' inf <- new_pd_infection(
#'   patient_id = "ABC0110",
#'   infection_date = as.Date("2025-03-01"),
#'   organism_list = list("Staphylococcus aureus"),
#'   last_dose_antibiotic = as.Date("2025-03-15")
#' )
#' cath <- new_pd_catheter(
#'   patient_id = "ABC0110", catheter_id = "ABC0110_01",
#'   insertion_date = as.Date("2024-12-01"), pd_start_date = as.Date("2024-12-15"),
#'   pd_stop_date = as.Date(NA), infections = list(inf),
#'   t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31")
#' )
#' subset(cath, infection_date >= as.Date("2025-03-01"))
#'
subset.pd_catheter <- function(x, subset, select, ...) {
  if (...length() > 0L) {
    stop("Unused argument(s) passed to subset(). A pd_catheter takes only a ",
         "condition and `select`.", call. = FALSE)
  }

  # the catheter does not know its patient's transfer date, so wrap it with an NA one
  wrapped <- list(list(catheters = list(x),
                       transfer_date = as.Date(NA)))
  catheters_tbl <- catheters_to_tibble(wrapped, x$t0, x$t1)
  catheters_tbl <- catheters_tbl[setdiff(names(catheters_tbl),
                                         "exposure_days_in_period")]

  flat <- flatten_pd_tables(patients = NULL,
                            catheters = catheters_tbl,
                            infections = infections_to_tibble(wrapped, x$t0, x$t1))
  subset_table(flat, rlang::enquo(subset), rlang::enquo(select))
}
