# Tests for R/pd_unit_summary.R

d <- function(x) as.Date(x)

timing_unit <- function(patients, catheters, infections) {
  list(patients = tibble::as_tibble(patients),
       catheters = tibble::as_tibble(catheters),
       infections = tibble::as_tibble(infections))
}

# Two incident patients (I1, I2), one prevalent (P1)
#   I1: first catheter inserted 2025-02-01, PD start 2025-02-11 (10 days); a second catheter later.
#       Episodes 2025-03-13 (31 days after first PD start) and 2025-09-01.
#   I2: inserted 2025-04-01, PD start 2025-04-21 (20 days); no episodes.
#   P1: prevalent, inserted 2024-01-01, PD start 2024-03-01 (60 days); an episode on 2025-01-10.
timing_fixture <- function() {
  timing_unit(
    patients = data.frame(patient_id = c("I1", "I2", "P1"),
                          new_patient_flag = c(TRUE, TRUE, FALSE)),
    catheters = data.frame(
      patient_id = c("I1", "I1", "I2", "P1"),
      catheter_id = c("I1_01", "I1_02", "I2_01", "P1_01"),
      insertion_date = d(c("2025-02-01", "2025-08-01", "2025-04-01", "2024-01-01")),
      pd_start_date = d(c("2025-02-11", "2025-08-10", "2025-04-21", "2024-03-01"))),
    infections = data.frame(
      patient_id = c("I1", "I1", "P1"),
      catheter_id = c("I1_01", "I1_02", "P1_01"),
      infection_date = d(c("2025-03-13", "2025-09-01", "2025-01-10"))))
}


test_that("time to PD start from insertion is the mean over incident patients' first catheters", {
  out <- summarise_catheters(timing_fixture())$time_to_pd_start_days
  # (10 + 20) / 2; the second catheter of I1 and the prevalent patient are not used
  expect_equal(out[["mean"]], 15)
  expect_equal(out[["n"]], 2)
  expect_named(out, c("mean", "n"))
})

test_that("time to first peritonitis episode is PD start to the first episode, among incident patients with one", {
  out <- summarise_catheters(timing_fixture())$time_to_first_peritonitis_days
  # only I1 has an episode: 2025-02-11 -> 2025-03-13 = 30 days
  expect_equal(out[["mean"]], as.numeric(d("2025-03-13") - d("2025-02-11")))
  expect_equal(out[["n"]], 1)
})

test_that("a patient's first catheter is the one with the earliest PD start, whatever the row order", {
  x <- timing_fixture()
  x$catheters <- x$catheters[c(2, 1, 3, 4), ]
  expect_equal(summarise_catheters(x)$time_to_pd_start_days[["mean"]], 15)
})

test_that("a catheter with no PD start date is ignored", {
  x <- timing_fixture()
  x$catheters$pd_start_date[x$catheters$catheter_id == "I2_01"] <- as.Date(NA)
  out <- summarise_catheters(x)$time_to_pd_start_days
  expect_equal(out[["mean"]], 10)
  expect_equal(out[["n"]], 1)
})

test_that("a missing insertion date drops that patient from the mean rather than breaking it", {
  x <- timing_fixture()
  x$catheters$insertion_date[x$catheters$catheter_id == "I1_01"] <- as.Date(NA)
  out <- summarise_catheters(x)$time_to_pd_start_days
  expect_equal(out[["mean"]], 20)
  expect_equal(out[["n"]], 1)
})

test_that("with no incident patients both measures are NA with n = 0", {
  x <- timing_fixture()
  x$patients$new_patient_flag <- FALSE
  out <- summarise_catheters(x)
  expect_true(is.na(out$time_to_pd_start_days[["mean"]]))
  expect_equal(out$time_to_pd_start_days[["n"]], 0)
  expect_true(is.na(out$time_to_first_peritonitis_days[["mean"]]))
  expect_equal(out$time_to_first_peritonitis_days[["n"]], 0)
})

test_that("with no episodes the time to first peritonitis is NA but the PD-start measure still works", {
  x <- timing_fixture()
  x$infections <- x$infections[0, ]
  out <- summarise_catheters(x)
  expect_true(is.na(out$time_to_first_peritonitis_days[["mean"]]))
  expect_equal(out$time_to_pd_start_days[["mean"]], 15)
})

test_that("summarise_catheters() still reports the catheter count and procedure types", {
  x <- timing_fixture()
  x$catheters$procedure_type <- c("Surgical", NA, "Surgical", "Percutaneous")
  out <- summarise_catheters(x)
  expect_equal(out$n_catheters, 4)
  expect_equal(as.list(out$procedure_type),
               list(Percutaneous = 1L, Surgical = 2L, unknown = 1L))
})


# summary.pd_unit() output

test_that("summary.pd_unit() prints the mean days, without a patient count", {
  # CCC0003 is the only incident patient: inserted 2025-02-01, PD start 2025-02-15,
  # first episode 2025-04-01
  txt <- capture.output(summary(make_subset_unit()))
  expect_match(grep("Time to PD start (mean)", txt, value = TRUE, fixed = TRUE),
               "14\\.0 days$")
  expect_match(grep("Time to 1st peritonitis (mean)", txt, value = TRUE, fixed = TRUE),
               "45\\.0 days$")
  expect_false(any(grepl("n = ", txt, fixed = TRUE)))
})

test_that("summary.pd_unit() prints NA when there are no incident patients", {
  unit <- make_subset_unit()
  unit$patients$new_patient_flag <- FALSE
  txt <- capture.output(summary(unit))
  expect_match(grep("Time to PD start (mean)", txt, value = TRUE, fixed = TRUE), "  NA$")
  expect_match(grep("Time to 1st peritonitis (mean)", txt, value = TRUE, fixed = TRUE), "  NA$")
})

test_that("summary.pd_unit() timing works on the unit built from the bundled files", {
  unit <- bundled_unit()
  capture.output(s <- summary(unit))
  tc <- s$catheters
  expect_equal(tc$time_to_pd_start_days[["n"]], unit$n_new)
  expect_equal(tc$time_to_pd_start_days[["mean"]], 14.65, tolerance = 0.01)
})


# benchmark

test_that("rate_met and pf_met are NA, not FALSE, when there is nothing to judge", {
  empty <- list(infections = tibble::tibble(), patients = tibble::tibble(),
                tpyar = 0, n_patients = 0L, rate_benchmark = 0.40)
  expect_true(is.na(summarise_rate(empty)$rate_met))
  expect_true(is.na(summarise_pf(empty)$pf_met))
})

test_that("rate_met and pf_met are still TRUE/FALSE when there is data", {
  unit <- list(
    infections = tibble::tibble(counts_toward_rate = c(TRUE, TRUE)),
    patients = tibble::tibble(n_episodes = c(0, 0, 0, 1, 2)),
    tpyar = 10, n_patients = 5L, rate_benchmark = 0.40)
  expect_equal(summarise_rate(unit)$rate, 0.2)
  expect_true(summarise_rate(unit)$rate_met)       # 0.2 <= 0.40
  expect_equal(summarise_pf(unit)$pf, 0.6)
  expect_false(summarise_pf(unit)$pf_met)          # 60% is not above 80%
})

test_that("summary.pd_unit() prints No Data, for an empty unit", {
  empty <- new_pd_unit(unit_id = "Empty", t0 = as.Date("2025-01-01"),
                       t1 = as.Date("2025-12-31"), n_new = 0L, n_patients = 0L, tpyar = 0)
  txt <- capture.output(summary(empty))
  expect_equal(sum(grepl("[ No Data ]", txt, fixed = TRUE)), 2)   # rate and PF lines
})


# peritonitis-free percentage and the length of the reporting period

test_that("period_is_one_year() counts both endpoints and accepts 365 or 366 days", {
  expect_true(period_is_one_year(d("2025-01-01"), d("2025-12-31")))   # 365 days
  expect_true(period_is_one_year(d("2024-01-01"), d("2024-12-31")))   # 366 days, leap year
  expect_true(period_is_one_year(d("2024-07-01"), d("2025-06-30")))   # financial year, 365
  expect_true(period_is_one_year(d("2023-07-01"), d("2024-06-30")))   # financial year with 29 February, 366
  expect_false(period_is_one_year(d("2025-01-01"), d("2025-06-30")))
  expect_false(period_is_one_year(d("2025-01-01"), d("2026-06-30")))
  expect_false(period_is_one_year(as.Date(NA), d("2025-12-31")))
})

test_that("summary.pd_unit() does not warn for a one-year reporting period", {
  unit <- make_subset_unit()
  expect_no_warning(capture.output(summary(unit)))
})

test_that("summary.pd_unit() warns that the PF percentage is not comparable when the period is not one year, but still returns the indicators", {
  unit <- make_subset_unit()

  unit$t1 <- d("2025-06-30")
  expect_warning(capture.output(summary(unit)), "181 days, not exactly one year")

  # the warning does not stop the calculation
  suppressWarnings(capture.output(s <- summary(unit)))
  expect_true(s$pf >= 0 && s$pf <= 1)
  expect_equal(s$pf_den, unit$n_patients)

  unit$t1 <- d("2026-06-30")
  expect_warning(capture.output(summary(unit)), "546 days, not exactly one year")
})

test_that("summary.pd_unit() does not raise the PF warning when there is no PF to report", {
  empty <- new_pd_unit(unit_id = "Empty", t0 = d("2025-01-01"), t1 = d("2025-06-30"),
                       n_new = 0L, n_patients = 0L, tpyar = 0)
  expect_no_warning(capture.output(summary(empty)))
})
