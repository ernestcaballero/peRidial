## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(peridial)

## ----unit, warning = FALSE----------------------------------------------------
# building this unit warns about SPD0012's first episode, explained in vignette("peridial")
unit <- pd_unit(
  unit_data = system.file("extdata", "a3_2025.xlsx", package = "peridial"),
  infection_data = system.file("extdata", "pe_2025.xlsx", package = "peridial"),
  t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
  unit_id = "Wellington PD Unit"
)

## ----worked-example-----------------------------------------------------------
episodes <- data.frame(
  infection_date = as.Date(c("2025-01-01", "2025-02-01", "2025-03-01", 
                             "2025-06-01", "2025-09-01")),
  last_dose_antibiotic = as.Date(c("2025-01-15", "2025-02-15", "2025-03-15", 
                                   "2025-06-15", "2025-09-15")),
  organism = c("E. coli", "E. coli", "Klebsiella", "Klebsiella", 
               "Staphylococcus aureus")
)

episodes$episode_type <- classify_episode_types(
  patient_id = rep("patient01", 5),
  infection_date = episodes$infection_date,
  last_dose_antibiotic = episodes$last_dose_antibiotic,
  organism_list = lapply(episodes$organism, list)
)
# days from the previous episode's last dose to this episode's infection date
episodes$gap_days <- c(NA, as.numeric(episodes$infection_date[-1] -
                                        episodes$last_dose_antibiotic[-5]))
episodes$counts <- is.na(episodes$episode_type) | episodes$episode_type != "relapsing"
episodes

## ----summary------------------------------------------------------------------
s <- summary(unit)

## ----reconcile----------------------------------------------------------------
# rate = countable episodes / patient-years at risk
numerator <- sum(unit$infections$counts_toward_rate)
c(numerator = numerator, patient_years = unit$tpyar, rate = numerator / unit$tpyar)

# the same patient-years from the catheter table, and from the patient table
c(from_catheters = sum(unit$catheters$exposure_days_in_period) / 365.25,
  from_patients = sum(unit$patients$patient_years_at_risk))

# PF = patients with no countable episode / patients in the cohort
mean(unit$patients$n_episodes == 0)

all.equal(c(s$rate, s$pf), c(numerator / unit$tpyar, mean(unit$patients$n_episodes == 0)))

## ----episode-types------------------------------------------------------------
table(unit$infections$episode_type, unit$infections$counts_toward_rate,
      useNA = "ifany", dnn = c("episode_type", "counts_toward_rate"))

## ----exposure-----------------------------------------------------------------
catheter <- list(pd_start_date = as.Date("2024-11-10"), pd_stop_date = as.Date(NA))

catheter_exposure_days(catheter,
                       t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
                       tau = as.Date("2025-09-30"))   # patient died on 30 September

## ----tpyar--------------------------------------------------------------------
total_patient_years(unit$patient_list, unit$t0, unit$t1)
unit$tpyar

## ----count--------------------------------------------------------------------
episode <- function(date) {
  pd_infection("patient01", as.Date(date), list("E. coli"),
               last_dose_antibiotic = as.Date(date) + 14)
}
infections <- list(episode("2025-12-20"), episode("2026-01-20"))

# the catheter runs on until February 2026, but the period ends on 31 December 2025
count_episodes(infections,
               t0 = as.Date("2025-01-01"), t1 = as.Date("2025-12-31"),
               pd_start_date = as.Date("2025-03-01"), pd_stop_date = as.Date("2026-02-15"))

## ----by-period----------------------------------------------------------------
peritonitis_rate_by_period(unit, cal.period = "quarter")

## ----get-type-----------------------------------------------------------------
first <- pd_infection("patient01", as.Date("2025-04-01"), list("E. coli"),
                      last_dose_antibiotic = as.Date("2025-04-15"))

get_episode_type(as.Date("2025-05-12"), list("E. coli"), prior_episode = first)

## ----classify-----------------------------------------------------------------
classify_episode_types(
  patient_id = c("patient01", "patient01", "patient02", "patient02"),
  infection_date = as.Date(c("2025-04-01", "2025-05-12", "2025-03-31", "2025-07-13")),
  last_dose_antibiotic = as.Date(c("2025-04-15", "2025-06-01", "2025-04-14", "2025-07-27")),
  organism_list = list(list("E. coli"), list("E. coli"), list("E. coli"), list("E. coli"))
)

## ----use-cpp------------------------------------------------------------------
x <- list(
  patient_id = c("patient01", "patient01", "patient02", "patient02"),
  infection_date = as.Date(c("2025-04-01", "2025-05-12", "2025-03-31", "2025-07-13")),
  last_dose_antibiotic = as.Date(c("2025-04-15", "2025-06-01", "2025-04-14", "2025-07-27")),
  organism_list = list(list("E. coli"), list("E. coli"), list("E. coli"), list("E. coli"))
)

identical(do.call(classify_episode_types, c(x, use_cpp = TRUE)),
          do.call(classify_episode_types, c(x, use_cpp = FALSE)))

## ----timing, eval = FALSE-----------------------------------------------------
# set.seed(1)
# n_patients <- 2000
# per_patient <- 10
# n <- n_patients * per_patient
# 
# first_date <- as.Date("2020-01-01") + sample(0:365, n_patients, replace = TRUE)
# infection_date <- rep(first_date, each = per_patient) +
#   rep((seq_len(per_patient) - 1) * 45, times = n_patients)
# organisms <- sample(c("E. coli", "Klebsiella", "Staphylococcus aureus", "negative"),
#                     n, replace = TRUE)
# 
# big <- list(
#   patient_id = rep(sprintf("P%04d", seq_len(n_patients)), each = per_patient),
#   infection_date = infection_date,
#   last_dose_antibiotic = infection_date + 14,
#   organism_list = lapply(organisms, list)
# )
# 
# system.time(cpp <- do.call(classify_episode_types, c(big, use_cpp = TRUE)))
# system.time(r <- do.call(classify_episode_types, c(big, use_cpp = FALSE)))
# identical(cpp, r)

