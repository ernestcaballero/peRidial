## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(peridial)

## -----------------------------------------------------------------------------
t0 <- as.Date("2025-01-01")           # first calendar day
t1 <- as.Date("2025-12-31")           # last calenday day

unit <- pd_unit(
  unit_data = system.file("extdata", "a3_2025.xlsx", package = "peridial"),
  infection_data = system.file("extdata", "pe_2025.xlsx", package = "peridial"),
  t0 = t0, t1 = t1, unit_id = "Wellington PD Unit"
)

unit

## ----eval = FALSE-------------------------------------------------------------
# raw_a3 <- readxl::read_excel("my_unit_export.xlsx")
# raw_pe <- readxl::read_excel("my_peritonitis_export.xlsx")
# 
# a3 <- data.frame(
#   "Patient ID" = raw_a3$MRN,
#   "Date of Birth" = raw_a3$DOB,
#   "Insertion Date" = raw_a3$CatheterInsertDate,
#   "PD Start Date" = raw_a3$PDStart,
#   "Gender" = ifelse(raw_a3$Sex == 1, "Male", "Female"),
#   check.names = FALSE
# )
# 
# pe <- data.frame(
#   "Patient ID"  = raw_pe$MRN,
#   "Date of Infection" = raw_pe$InfectionDate,
#   "Organism" = raw_pe$Organism,
#   check.names = FALSE
# )
# 
# unit <- pd_unit(
#   unit_data = a3,
#   infection_data = pe,
#   t0 = as.Date("2025-01-01"),
#   t1 = as.Date("2025-12-31"),
#   unit_id = "Your PD Unit"
# )

## -----------------------------------------------------------------------------
tryCatch(
  pd_unit(
    unit_data = system.file("extdata", "a3_2025_messy.xlsx", package = "peridial"),
    infection_data = system.file("extdata", "pe_2025_messy.xlsx", package = "peridial"),
    t0 = t0, t1 = t1, unit_id = "Messy PD Unit"
  ),
  error = function(e) cat(conditionMessage(e))
)

## -----------------------------------------------------------------------------
pat <- Filter(function(p) p$patient_id == "SPD0059", unit$patient_list)[[1]]
pat

## -----------------------------------------------------------------------------
pat$catheters[[2]]

## -----------------------------------------------------------------------------
spd0003 <- Filter(function(p) p$patient_id == "SPD0003", unit$patient_list)[[1]]
spd0003$catheters[[1]]$infections[[2]]

## -----------------------------------------------------------------------------
s <- summary(unit)

## -----------------------------------------------------------------------------
s$rate
s$rate_met
s$episode_types
s$demographics$dialysis_type
s$catheters$time_to_first_peritonitis_days["mean"]

## -----------------------------------------------------------------------------
summary(spd0003)

## ----fig.width = 7, fig.height = 4.5, eval = requireNamespace("ggplot2", quietly = TRUE)----
plot(unit, type = "monthly")

## ----fig.width = 7, fig.height = 6, eval = requireNamespace("ggplot2", quietly = TRUE) && requireNamespace("patchwork", quietly = TRUE)----
plot(unit, type = "yearly")

## ----eval = FALSE-------------------------------------------------------------
# plot(unit, type = "yearly", benchmark = 0.50,
#      show_ip = TRUE,            # incident vs prevalent
#      show_pkd = TRUE,           # primary kidney disease
#      show_modality = TRUE,      # CAPD / APD / hybrid
#      show_stop.reason = TRUE)   # why catheters were stopped

## -----------------------------------------------------------------------------
subset(unit, episode_type == "recurrent",
       select = c(patient_id, catheter_id, infection_date, organisms, episode_type))

## -----------------------------------------------------------------------------
nrow(subset(unit))
nrow(subset(unit, !is.na(infection_date)))
dplyr::n_distinct(subset(unit)$patient_id)

## -----------------------------------------------------------------------------
subset(pat, select = c(catheter_id, pd_start_date, pd_stop_date, removal_reason))

