## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning = FALSE---------------------------------------------------
# building this unit warns about SPD0012's first episode, explained in vignette("peridial")
library(peridial)

t0 <- as.Date("2025-01-01")
t1 <- as.Date("2025-12-31")

unit <- pd_unit(
  unit_data = system.file("extdata", "a3_2025.xlsx", package = "peridial"),
  infection_data = system.file("extdata", "pe_2025.xlsx", package = "peridial"),
  t0 = t0, t1 = t1, unit_id = "Wellington PD Unit"
)

## -----------------------------------------------------------------------------
spd0003 <- Filter(function(p) p$patient_id == "SPD0003", unit$patient_list)[[1]]

names(spd0003)
names(spd0003$catheters[[1]])
names(spd0003$catheters[[1]]$infections[[1]])

## -----------------------------------------------------------------------------
names(unit)

## -----------------------------------------------------------------------------
lapply(unit[c("patients", "catheters", "infections")], names)

## -----------------------------------------------------------------------------
tryCatch(
  pd_infection(
    patient_id = "ABC1234",
    infection_date = as.Date("2025-03-10"),
    organism_list = list("Staphylococcus aureus")
  ),
  error = function(e) conditionMessage(e)
)

## -----------------------------------------------------------------------------
too_early <- pd_infection(
  patient_id = "ABC1234",
  infection_date = as.Date("2024-10-01"),
  organism_list = list("Escherichia coli"),
  last_dose_antibiotic = as.Date("2024-10-15")
)

tryCatch(
  pd_catheter(
    patient_id = "ABC1234",
    catheter_id = "ABC1234_01",
    insertion_date = as.Date("2024-11-02"),
    pd_start_date = as.Date("2024-11-20"),
    infections = list(too_early),
    t0 = t0, t1 = t1
  ),
  error = function(e) conditionMessage(e)
)

